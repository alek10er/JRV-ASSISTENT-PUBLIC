﻿import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import tempfile
import threading
import time
import zipfile
from datetime import datetime, timezone
from html import unescape
from pathlib import Path
from urllib.parse import unquote

import requests
import tkinter as tk
from tkinter import filedialog

try:
    import webview
except Exception:
    webview = None

SUPABASE_URL = "https://hikpmunrcmlqgjnzkmhd.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhpa3BtdW5yY21scWdqbnprbWhkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgxNTE4OTUsImV4cCI6MjA4MzcyNzg5NX0.FSDQLHcglva97FWOHcvXVFGn9lJC0nHGxbmnHpiDL8k"
TABLE_NAME = "users"

GITHUB_REPO_URL = "https://github.com/alek10er/JRV-ASSISTENT-PUBLIC/tree/RECOVERE-RELES"
GITHUB_OWNER = "alek10er"
GITHUB_REPO = "JRV-ASSISTENT-PUBLIC"
GITHUB_BRANCH = "RECOVERE-RELES"
SUPPORTED_ARCHIVE_EXTENSIONS = (".zip", ".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".tar.xz", ".txz")
PREFERRED_ARCHIVE_NAME = "JARVIS USER RELES FINAl.zip"

INSTALLATION_TEXTS = {
    "english": {
        "folder_dialog_title": "Select JARVIS Installation Folder",
        "error_no_path": "Please select installation path",
        "error_install_failed": "Installation failed: {}",
        "progress_creating": "Creating JARVIS directory...",
        "progress_downloading_exe": "Downloading JARVIS archive...",
        "progress_downloading_files": "Extracting archive files...",
        "progress_configs": "Cleaning old installation files...",
        "progress_model": "Installing new JARVIS files...",
        "progress_finalizing": "Finalizing installation...",
        "progress_completed": "Installation completed successfully!",
        "readme_title": "JARVIS Installation",
        "readme_installed_for": "Installed for: {}",
        "readme_date": "Installation date: {}",
        "readme_location": "Location: {}",
        "readme_run": "To start JARVIS, run: JARVIS.exe",
        "error_launch": "JARVIS executable not found!",
        "error_folder": "Installation folder not found!",
        "log_launched": "JARVIS launched successfully!",
        "log_folder_opened": "Installation folder opened",
    },
    "russian": {
        "folder_dialog_title": "Выберите папку для установки JARVIS",
        "error_no_path": "Пожалуйста, выберите путь установки",
        "error_install_failed": "Ошибка установки: {}",
        "progress_creating": "Создание директории JARVIS...",
        "progress_downloading_exe": "Загрузка архива JARVIS...",
        "progress_downloading_files": "Распаковка файлов архива...",
        "progress_configs": "Очистка старых файлов установки...",
        "progress_model": "Установка новых файлов JARVIS...",
        "progress_finalizing": "Завершение установки...",
        "progress_completed": "Установка успешно завершена!",
        "readme_title": "Установка JARVIS",
        "readme_installed_for": "Установлено для: {}",
        "readme_date": "Дата установки: {}",
        "readme_location": "Расположение: {}",
        "readme_run": "Для запуска JARVIS, запустите: JARVIS.exe",
        "error_launch": "Исполняемый файл JARVIS не найден!",
        "error_folder": "Папка установки не найдена!",
        "log_launched": "JARVIS успешно запущен!",
        "log_folder_opened": "Папка установки открыта",
    },
}


class WebInstallerApi:
    def __init__(self):
        self.language = "russian"
        self.username = ""
        self._window = None
        self._closed = False
        self.installation_path = self._get_default_installation_path()
        self.installation_in_progress = False
        self._last_log_time = 0.0
        self._last_log_percent = -1
        self._log_interval = 0.5
        self._log_percent_step = 5

        root = tk.Tk()
        root.withdraw()
        self.screen_width = root.winfo_screenwidth()
        self.screen_height = root.winfo_screenheight()
        root.destroy()

        self.compact_width = 900
        self.compact_height = 520
        self.expanded_width = 930
        self.expanded_height = 640
        # Startup without animation: open immediately at compact size.
        self.start_width = self.compact_width
        self.start_height = self.compact_height
        self.final_width = self.compact_width
        self.final_height = self.compact_height
        self._window_width = self.start_width
        self._window_height = self.start_height

    @staticmethod
    def _get_default_installation_path():
        home_dir = Path(os.path.expanduser("~"))
        userprofile = os.environ.get("USERPROFILE", "").strip()
        candidates = [home_dir / "Downloads"]
        if userprofile:
            candidates.append(Path(userprofile) / "Downloads")
        candidates.append(home_dir)

        for base_dir in candidates:
            try:
                if base_dir and base_dir.exists():
                    return str(base_dir / "JARVIS")
            except Exception:
                continue

        return str(home_dir / "JARVIS")

    def attach_window(self, window):
        self._window = window

    def on_start(self):
        return

    def ui_ready(self):
        return {"ok": True}

    def _start_open_animation(self):
        # Startup animation is disabled by user request.
        return

    def set_window_mode(self, mode):
        if not self._window:
            return {"ok": False, "error": "window_not_ready"}

        normalized = str(mode or "").strip().lower()
        if normalized == "compact":
            width, height = self.compact_width, self.compact_height
        elif normalized == "expanded":
            width, height = self.expanded_width, self.expanded_height
        else:
            return {"ok": False, "error": "unknown_mode"}

        try:
            self._window.resize(width, height)
            self._window_width = width
            self._window_height = height
            return {"ok": True, "mode": normalized}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _emit(self, event, payload):
        if not self._window or self._closed:
            return
        try:
            message = json.dumps({"event": event, "payload": payload}, ensure_ascii=False)
            self._window.evaluate_js(f"window.JARVIS_BRIDGE && window.JARVIS_BRIDGE.receive({message});")
        except Exception:
            pass

    def _log(self, message):
        ts = datetime.now().strftime("%H:%M:%S")
        self._emit("install_log", {"message": f"[{ts}] {message}"})

    def _progress(self, value, message):
        self._emit("install_progress", {"value": int(value), "message": message})
        self._log(message)

    def get_bootstrap_data(self):
        if not str(self.installation_path or "").strip():
            self.installation_path = self._get_default_installation_path()
        return {
            "language": self.language,
            "username": self.username,
            "installPath": self.installation_path,
        }

    def change_language(self, language):
        if language in INSTALLATION_TEXTS:
            self.language = language
            return {"ok": True}
        return {"ok": False, "error": "Unsupported language"}

    def window_control(self, action):
        if not self._window:
            return {"ok": False}
        try:
            if action == "close":
                self._closed = True
                self._window.destroy()
                return {"ok": True}
            if action == "minimize":
                self._window.minimize()
                return {"ok": True}
            if action == "maximize":
                return {"ok": False, "error": "Window resize is disabled"}
        except Exception as e:
            return {"ok": False, "error": str(e)}
        return {"ok": False, "error": "Unknown action"}
    def get_hwid(self):
        try:
            def run_cmd(cmd):
                try:
                    return subprocess.check_output(cmd, shell=True, text=True, errors="ignore", timeout=5, stderr=subprocess.DEVNULL)
                except Exception:
                    return ""

            def parse_value(output):
                if not output:
                    return ""
                lines = [line.strip() for line in output.splitlines() if line.strip()]
                if not lines:
                    return ""
                if len(lines) == 1 and "=" in lines[0]:
                    return lines[0].split("=", 1)[1].strip()
                if len(lines) >= 2 and lines[0].replace(" ", "").lower() in {"serialnumber", "processorid", "uuid"}:
                    lines = lines[1:]
                return lines[0].strip() if lines else ""

            def clean(value):
                if not value:
                    return ""
                value = value.strip()
                if not value:
                    return ""
                lower = value.lower()
                invalid = ["to be filled", "default string", "unknown", "none", "n/a", "invalid", "o.e.m", "oem", "not applicable"]
                if any(token in lower for token in invalid):
                    return ""
                return value

            def first_value(commands):
                for cmd in commands:
                    if not cmd:
                        continue
                    v = clean(parse_value(run_cmd(cmd)))
                    if v:
                        return v
                return ""

            parts = []
            if os.name == "nt":
                has_wmic = shutil.which("wmic") is not None
                bios = first_value(["wmic bios get serialnumber /value" if has_wmic else "", "powershell -NoProfile -Command \"(Get-CimInstance Win32_BIOS).SerialNumber\""])
                baseboard = first_value(["wmic baseboard get serialnumber /value" if has_wmic else "", "powershell -NoProfile -Command \"(Get-CimInstance Win32_BaseBoard).SerialNumber\""])
                cpu = first_value(["wmic cpu get processorid /value" if has_wmic else "", "powershell -NoProfile -Command \"(Get-CimInstance Win32_Processor | Select-Object -First 1).ProcessorId\""])
                disk = first_value(["wmic diskdrive get serialnumber /value" if has_wmic else "", "powershell -NoProfile -Command \"(Get-CimInstance Win32_DiskDrive | Select-Object -First 1).SerialNumber\""])
                sys_uuid = first_value(["wmic csproduct get uuid /value" if has_wmic else "", "powershell -NoProfile -Command \"(Get-CimInstance Win32_ComputerSystemProduct).UUID\""])
                if bios:
                    parts.append(f"bios:{bios}")
                if baseboard:
                    parts.append(f"baseboard:{baseboard}")
                if cpu:
                    parts.append(f"cpu:{cpu}")
                if disk:
                    parts.append(f"disk:{disk}")
                if sys_uuid:
                    parts.append(f"uuid:{sys_uuid}")
            if not parts:
                parts.append(f"{platform.node()}{platform.processor()}{platform.machine()}")
            return hashlib.sha256("|".join(parts).encode()).hexdigest()
        except Exception:
            fallback_parts = [
                platform.node(),
                platform.processor(),
                platform.machine(),
                os.environ.get("COMPUTERNAME", ""),
            ]
            fallback = "|".join([part for part in fallback_parts if part])
            if not fallback:
                fallback = "jarvis-unknown-device"
            return hashlib.sha256(fallback.encode()).hexdigest()

    def check_hwid(self):
        hwid = str(self.get_hwid() or "").strip()
        if not hwid:
            return {"ok": False, "error": "error_hwid_unavailable"}

        try:
            response = requests.get("https://google.com", timeout=5)
            if response.status_code != 200:
                return {"ok": False, "error": "error_internet", "hwid": hwid}
        except Exception:
            return {"ok": False, "error": "error_internet", "hwid": hwid}

        headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}",
            "Content-Type": "application/json",
            "Prefer": "return=representation",
        }

        try:
            response = requests.get(
                f"{SUPABASE_URL}/rest/v1/{TABLE_NAME}",
                headers=headers,
                timeout=15,
            )
            if response.status_code != 200:
                return {"ok": False, "error": "error_unknown", "hwid": hwid}

            records = response.json()
            if not isinstance(records, list):
                records = []

            user_data = None
            legacy_match = False
            for record in records:
                stored_hwid = str(record.get("hwid") or "")
                if not stored_hwid:
                    continue
                is_legacy = len(stored_hwid) == 32 and stored_hwid == hwid[:32]
                is_full = stored_hwid == hwid
                if is_full or is_legacy:
                    user_data = record
                    legacy_match = is_legacy
                    break

            if not user_data:
                return {"ok": False, "error": "error_hwid_not_allowed", "hwid": hwid}

            first_name = str(user_data.get("first_name") or "User")
            key_expiry = str(user_data.get("key_expiry") or "").strip()
            telegram_id = user_data.get("telegram_id")
            device_count = int(user_data.get("device_count", 0) or 0)
            last_activation = str(user_data.get("last_activation") or "").strip()

            expiry_dt = None
            if key_expiry:
                normalized = key_expiry[:-1] + "+00:00" if key_expiry.endswith("Z") else key_expiry
                try:
                    expiry_dt = datetime.fromisoformat(normalized)
                except Exception:
                    expiry_dt = None
                if expiry_dt is not None and expiry_dt.tzinfo is None:
                    expiry_dt = expiry_dt.replace(tzinfo=timezone.utc)
            if expiry_dt is not None and expiry_dt < datetime.now(timezone.utc):
                return {"ok": False, "error": "error_hwid_expired", "hwid": hwid}

            if legacy_match and telegram_id:
                try:
                    requests.patch(
                        f"{SUPABASE_URL}/rest/v1/{TABLE_NAME}",
                        headers=headers,
                        params={"telegram_id": f"eq.{telegram_id}"},
                        json={
                            "hwid": hwid,
                            "last_activation": datetime.now().isoformat(),
                        },
                        timeout=15,
                    )
                except Exception:
                    pass

            self.username = first_name
            return {
                "ok": True,
                "hwid": hwid,
                "username": first_name,
                "keyExpiry": key_expiry,
                "deviceCount": device_count,
                "lastActivation": last_activation,
            }
        except requests.exceptions.RequestException:
            return {"ok": False, "error": "error_internet", "hwid": hwid}
        except Exception:
            return {"ok": False, "error": "error_unknown", "hwid": hwid}

    def activate_code(self, code):
        code = str(code or "").strip()
        if not code:
            return {"ok": False, "error": "error_code_required"}
        try:
            try:
                response = requests.get("https://google.com", timeout=5)
                if response.status_code != 200:
                    return {"ok": False, "error": "error_internet"}
            except Exception:
                return {"ok": False, "error": "error_internet"}

            hwid = self.get_hwid()
            headers = {
                "apikey": SUPABASE_KEY,
                "Authorization": f"Bearer {SUPABASE_KEY}",
                "Content-Type": "application/json",
                "Prefer": "return=representation",
            }
            response = requests.get(f"{SUPABASE_URL}/rest/v1/{TABLE_NAME}", headers=headers, timeout=15)
            if response.status_code != 200:
                return {"ok": False, "error": "error_unknown"}

            data = response.json()
            if not isinstance(data, list):
                data = []
            user = next((record for record in data if record.get("subscription_key") == code), None)
            if not user:
                return {"ok": False, "error": "error_incorrect"}

            device_count = int(user.get("device_count", 0) or 0)
            stored_hwid = str(user.get("hwid") or "")
            first_name = str(user.get("first_name") or "User")
            telegram_id = user.get("telegram_id")
            key_expiry = str(user.get("key_expiry") or "").strip()

            expiry_dt = None
            if key_expiry:
                normalized = key_expiry[:-1] + "+00:00" if key_expiry.endswith("Z") else key_expiry
                try:
                    expiry_dt = datetime.fromisoformat(normalized)
                except Exception:
                    expiry_dt = None
                if expiry_dt is not None and expiry_dt.tzinfo is None:
                    expiry_dt = expiry_dt.replace(tzinfo=timezone.utc)
            if expiry_dt is not None and expiry_dt < datetime.now(timezone.utc):
                return {"ok": False, "error": "error_hwid_expired"}

            if stored_hwid == "":
                update_data = {
                    "device_count": device_count + 1,
                    "hwid": hwid,
                    "last_activation": datetime.now().isoformat(),
                }
                if not telegram_id:
                    return {"ok": False, "error": "error_unknown"}
                update_response = requests.patch(
                    f"{SUPABASE_URL}/rest/v1/{TABLE_NAME}",
                    headers=headers,
                    params={"telegram_id": f"eq.{telegram_id}"},
                    json=update_data,
                    timeout=15,
                )
                if update_response.status_code not in [200, 204]:
                    return {"ok": False, "error": "error_unknown"}
            else:
                legacy_match = len(stored_hwid) == 32 and stored_hwid == hwid[:32]
                full_match = stored_hwid == hwid
                if not (full_match or legacy_match):
                    return {"ok": False, "error": "error_hwid"}
                if legacy_match and telegram_id:
                    try:
                        requests.patch(
                            f"{SUPABASE_URL}/rest/v1/{TABLE_NAME}",
                            headers=headers,
                            params={"telegram_id": f"eq.{telegram_id}"},
                            json={
                                "hwid": hwid,
                                "last_activation": datetime.now().isoformat(),
                            },
                            timeout=15,
                        )
                    except Exception:
                        pass

            self.username = first_name
            return {"ok": True, "username": first_name, "hwid": hwid}
        except requests.exceptions.RequestException:
            return {"ok": False, "error": "error_internet"}
        except Exception:
            return {"ok": False, "error": "error_unknown"}

    def browse_install_path(self):
        texts = INSTALLATION_TEXTS[self.language]
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        default_dir = Path(self.installation_path).parent if self.installation_path else Path(os.path.expanduser("~"))
        if not default_dir.exists():
            default_dir = Path(os.path.expanduser("~"))
        folder = filedialog.askdirectory(title=texts["folder_dialog_title"], initialdir=str(default_dir))
        root.destroy()
        if folder:
            self.installation_path = os.path.join(folder, "JARVIS")
        return {"ok": True, "path": self.installation_path}

    def start_installation(self, install_path):
        if self.installation_in_progress:
            return {"ok": False, "error": "Установка уже выполняется"}
        install_path = str(install_path or "").strip()
        if not install_path:
            return {"ok": False, "error": INSTALLATION_TEXTS[self.language]["error_no_path"]}

        hwid_check = self.check_hwid()
        if not hwid_check.get("ok"):
            return {"ok": False, "error": hwid_check.get("error", "error_hwid_not_allowed")}

        self.installation_path = install_path
        self.installation_in_progress = True
        self._emit("install_progress", {"value": 0, "message": ""})
        threading.Thread(target=self._installation_process, args=(install_path, self.language), daemon=True).start()
        return {"ok": True}

    def _installation_process(self, install_path, lang_snapshot):
        temp_dir = None
        texts = INSTALLATION_TEXTS.get(lang_snapshot, INSTALLATION_TEXTS["english"])
        try:
            self._progress(10, texts["progress_creating"])
            jarvis_path = Path(install_path)
            jarvis_path.mkdir(parents=True, exist_ok=True)

            self._progress(20, texts["progress_downloading_exe"])
            archive_url, archive_name = self.find_release_archive()
            temp_dir = Path(tempfile.mkdtemp(prefix="jarvis_inst_"))
            archive_path = temp_dir / archive_name
            self._log(f"Downloading: {archive_name}")
            if not self.download_file(archive_url, archive_path, archive_name):
                raise RuntimeError(f"Не удалось скачать архив: {archive_name}")

            self._progress(45, texts["progress_downloading_files"])
            extract_dir = temp_dir / "extract"
            extract_dir.mkdir(parents=True, exist_ok=True)
            self.extract_archive(archive_path, extract_dir)
            payload_root = self.resolve_payload_root(extract_dir)

            self._progress(70, texts["progress_configs"])
            self.clear_directory_contents(jarvis_path)
            self._progress(85, texts["progress_model"])
            self.copy_payload(payload_root, jarvis_path)

            exe_path = jarvis_path / "JARVIS.exe"
            if not exe_path.exists():
                raise RuntimeError("После распаковки не найден JARVIS.exe")

            self._progress(95, texts["progress_finalizing"])
            readme_path = jarvis_path / "README.txt"
            with open(readme_path, "w", encoding="utf-8") as f:
                f.write(f"{texts['readme_title']}\n")
                f.write(f"{'=' * len(texts['readme_title'])}\n")
                f.write(f"{texts['readme_installed_for'].format(self.username)}\n")
                f.write(f"{texts['readme_date'].format(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}\n")
                f.write(f"{texts['readme_location'].format(jarvis_path)}\n")
                f.write(f"\n{texts['readme_run']}\n")

            self._progress(100, texts["progress_completed"])
            self._emit("install_done", {"ok": True, "path": str(jarvis_path)})
        except Exception as e:
            message = texts["error_install_failed"].format(str(e))
            self._progress(0, message)
            self._log(f"Error: {str(e)}")
            self._emit("install_done", {"ok": False, "error": message})
        finally:
            if temp_dir is not None:
                try:
                    shutil.rmtree(temp_dir, ignore_errors=True)
                except Exception:
                    pass
            self.installation_in_progress = False
    def find_release_archive(self):
        preferred_raw_url = (
            f"https://raw.githubusercontent.com/{GITHUB_OWNER}/{GITHUB_REPO}/"
            f"{GITHUB_BRANCH}/{PREFERRED_ARCHIVE_NAME.replace(' ', '%20')}"
        )
        if self.url_exists(preferred_raw_url):
            return preferred_raw_url, PREFERRED_ARCHIVE_NAME

        try:
            page = requests.get(GITHUB_REPO_URL, headers={"User-Agent": "JARVIS-Installer"}, timeout=20)
            page.raise_for_status()
            html_text = page.text
            pattern = re.compile(rf'href="(/{re.escape(GITHUB_OWNER)}/{re.escape(GITHUB_REPO)}/blob/{re.escape(GITHUB_BRANCH)}/[^"]+)"')
            matches = pattern.findall(html_text)
            candidates = []
            for href in matches:
                normalized_href = unescape(href)
                file_path = normalized_href.split(f"/blob/{GITHUB_BRANCH}/", 1)[-1]
                file_path = unquote(file_path)
                if file_path.lower().endswith(SUPPORTED_ARCHIVE_EXTENSIONS):
                    raw_url = f"https://raw.githubusercontent.com/{GITHUB_OWNER}/{GITHUB_REPO}/{GITHUB_BRANCH}/{file_path}"
                    candidates.append((Path(file_path).name, raw_url))
            if candidates:
                candidates = list({(name, url) for name, url in candidates})
                candidates.sort(key=lambda x: x[0].lower(), reverse=True)
                return candidates[0][1], candidates[0][0]
        except Exception:
            pass

        api_url = f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}/contents"
        headers = {"Accept": "application/vnd.github.v3+json", "User-Agent": "JARVIS-Installer"}
        response = requests.get(api_url, headers=headers, params={"ref": GITHUB_BRANCH}, timeout=20)
        response.raise_for_status()
        entries = response.json()
        if not isinstance(entries, list):
            raise RuntimeError("Некорректный ответ GitHub API")

        archives = []
        for item in entries:
            if item.get("type") != "file":
                continue
            name = str(item.get("name", ""))
            if name.lower().endswith(SUPPORTED_ARCHIVE_EXTENSIONS):
                download_url = item.get("download_url")
                if download_url:
                    archives.append((name, download_url))

        if not archives:
            raise RuntimeError("В ветке RECOVERE-RELES не найден архив сборки")

        archives.sort(key=lambda x: x[0].lower(), reverse=True)
        name, url = archives[0]
        return url, name

    def url_exists(self, url):
        try:
            response = requests.head(url, headers={"User-Agent": "JARVIS-Installer"}, timeout=15, allow_redirects=True)
            if response.status_code == 405:
                response = requests.get(url, headers={"User-Agent": "JARVIS-Installer", "Range": "bytes=0-0"}, timeout=20, stream=True)
            status_ok = 200 <= response.status_code < 300
            response.close()
            return status_ok
        except Exception:
            return False

    def extract_archive(self, archive_path, extract_dir):
        archive_name = str(archive_path).lower()
        if archive_name.endswith(".zip"):
            with zipfile.ZipFile(archive_path, "r") as archive:
                archive.extractall(extract_dir)
            return
        shutil.unpack_archive(str(archive_path), str(extract_dir))

    def resolve_payload_root(self, extract_dir):
        for candidate in extract_dir.rglob("JARVIS.exe"):
            return candidate.parent
        children = [p for p in extract_dir.iterdir() if p.is_dir()]
        if len(children) == 1:
            return children[0]
        return extract_dir

    def clear_directory_contents(self, target_dir):
        target_dir.mkdir(parents=True, exist_ok=True)
        for item in target_dir.iterdir():
            if item.is_dir():
                shutil.rmtree(item, ignore_errors=True)
            else:
                item.unlink(missing_ok=True)

    def copy_payload(self, source_dir, target_dir):
        source_dir = Path(source_dir)
        target_dir = Path(target_dir)
        target_dir.mkdir(parents=True, exist_ok=True)
        for item in source_dir.iterdir():
            destination = target_dir / item.name
            if item.is_dir():
                shutil.copytree(item, destination, dirs_exist_ok=True)
            else:
                shutil.copy2(item, destination)

    def download_file(self, url, file_path, file_name):
        url_variants = [url]
        if "github.com" in url and "/blob/" in url:
            url_variants.append(url.replace("github.com/", "raw.githubusercontent.com/").replace("/blob/", "/"))

        last_error = None
        for current_url in dict.fromkeys(url_variants):
            for attempt in range(1, 4):
                response = None
                try:
                    self._log(f"Source: {current_url} (attempt {attempt}/3)")
                    response = requests.get(current_url, headers={"User-Agent": "Mozilla/5.0"}, stream=True, timeout=45)
                    response.raise_for_status()
                    total_size = int(response.headers.get("content-length", 0))
                    downloaded = 0
                    self._last_log_time = 0.0
                    self._last_log_percent = -1
                    with open(file_path, "wb") as f:
                        for chunk in response.iter_content(chunk_size=8192):
                            if not chunk:
                                continue
                            f.write(chunk)
                            downloaded += len(chunk)
                            if total_size > 0:
                                percent = (downloaded / total_size) * 100
                                now = time.time()
                                if (percent - self._last_log_percent >= self._log_percent_step or now - self._last_log_time >= self._log_interval or percent >= 100):
                                    self._last_log_percent = percent
                                    self._last_log_time = now
                                    self._log(f"{file_name}: {downloaded/1024/1024:.1f}MB / {total_size/1024/1024:.1f}MB ({percent:.1f}%)")
                    return True
                except Exception as e:
                    last_error = e
                    self._log(f"Failed to download {file_name}: {str(e)}")
                    if attempt < 3:
                        time.sleep(1.0 * attempt)
                finally:
                    if response is not None:
                        try:
                            response.close()
                        except Exception:
                            pass
        if last_error is not None:
            self._log(f"Download failed after retries: {last_error}")
        return False

    def launch_jarvis(self, install_path):
        install_path = str(install_path or self.installation_path).strip()
        candidates = [Path(install_path) / "JARVIS.exe", Path(install_path) / "JarvisAssistant.V6.PUBLIC.exe"]
        exe_path = next((p for p in candidates if p.exists()), None)
        if exe_path is None:
            return {"ok": False, "error": INSTALLATION_TEXTS[self.language]["error_launch"]}
        try:
            subprocess.Popen([str(exe_path)], cwd=install_path)
            return {"ok": True, "message": INSTALLATION_TEXTS[self.language]["log_launched"]}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def open_installation_folder(self, install_path):
        install_path = str(install_path or self.installation_path).strip()
        if not os.path.exists(install_path):
            return {"ok": False, "error": INSTALLATION_TEXTS[self.language]["error_folder"]}
        try:
            if os.name == "nt":
                os.startfile(install_path)
            elif os.name == "posix":
                subprocess.Popen(["xdg-open", install_path])
            else:
                subprocess.Popen(["open", install_path])
            return {"ok": True, "message": INSTALLATION_TEXTS[self.language]["log_folder_opened"]}
        except Exception as e:
            return {"ok": False, "error": str(e)}


def launch_web_activation_installer(html_path=None):
    if webview is None:
        raise RuntimeError("pywebview is not installed")

    if html_path:
        html_file = Path(html_path)
    else:
        html_file = Path(__file__).with_name("installer_web.html")
    if not html_file.exists():
        raise RuntimeError(f"HTML UI file not found: {html_file}")
    html_content = html_file.read_text(encoding="utf-8")

    api = WebInstallerApi()
    x = max(0, (api.screen_width - api.final_width) // 2)
    y = max(0, (api.screen_height - api.final_height) // 2)
    window = webview.create_window(
        "J.A.R.V.I.S. Installer",
        html=html_content,
        width=api.start_width,
        height=api.start_height,
        x=x,
        y=y,
        background_color="#030407",
        frameless=True,
        easy_drag=True,
        resizable=False,
        on_top=False,
        js_api=api,
    )
    api.attach_window(window)
    webview.start(api.on_start, debug=False, http_server=True, private_mode=False)


if __name__ == "__main__":
    launch_web_activation_installer()
