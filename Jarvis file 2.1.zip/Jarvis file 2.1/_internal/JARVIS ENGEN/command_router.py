import re

import config_manager
from text_normalizer import normalize_text


class CommandRouter:
    def __init__(self):
        self.active = False
        self.reload()

    def reload(self):
        config_manager.ensure_configs()
        self.activation_phrases = [
            normalize_text(p) for p in config_manager.load_activation_phrases()
        ]
        self.deactivation_phrases = [
            normalize_text(p) for p in config_manager.load_deactivation_phrases()
        ]
        self.commands = config_manager.load_commands()

        self.phrase_index = []
        self.pattern_index = []

        for cmd in self.commands:
            cmd_type = cmd.get("type", "phrase")
            phrases = [normalize_text(p) for p in cmd.get("phrases", []) if p]
            if cmd_type == "pattern":
                self.pattern_index.append(
                    {
                        "command": cmd,
                        "phrases": phrases,
                    }
                )
            else:
                for phrase in phrases:
                    self.phrase_index.append((phrase, cmd))

        self.phrase_index.sort(key=lambda x: len(x[0]), reverse=True)

    def _phrase_in_text(self, text, phrase):
        if not phrase:
            return False
        pattern = r"(^|\s)" + re.escape(phrase) + r"($|\s)"
        return re.search(pattern, text) is not None

    def _contains_any(self, text, phrases):
        for phrase in phrases:
            if self._phrase_in_text(text, phrase):
                return True
        return False

    def _find_pattern_command(self, text):
        for entry in self.pattern_index:
            cmd = entry["command"]
            for prefix in entry["phrases"]:
                if not prefix:
                    continue
                pattern = r"(?:^|\s)" + re.escape(prefix) + r"\s+(.+)$"
                match = re.search(pattern, text)
                if match:
                    query = match.group(1).strip()
                    if query:
                        return {
                            "command": cmd,
                            "params": {"query": query},
                        }
        return None

    def _find_phrase_command(self, text):
        for phrase, cmd in self.phrase_index:
            if self._phrase_in_text(text, phrase):
                return {
                    "command": cmd,
                    "params": {},
                }
        return None

    def find_command(self, text):
        pattern_hit = self._find_pattern_command(text)
        if pattern_hit:
            return pattern_hit
        return self._find_phrase_command(text)

    def process(self, text):
        normalized = normalize_text(text)
        if not normalized:
            return {"event": "ignore", "normalized": ""}

        if self._contains_any(normalized, self.deactivation_phrases):
            if self.active:
                self.active = False
                return {
                    "event": "deactivated",
                    "normalized": normalized,
                }
            return {"event": "ignore", "normalized": normalized}

        was_active = self.active
        activation_present = self._contains_any(normalized, self.activation_phrases)
        activation_only = normalized in self.activation_phrases

        if not self.active and not activation_present:
            return {"event": "ignore", "normalized": normalized}

        if activation_present and not self.active:
            self.active = True

        command_hit = self.find_command(normalized)
        if command_hit:
            return {
                "event": "command",
                "normalized": normalized,
                "command": command_hit["command"],
                "params": command_hit.get("params", {}),
            }

        if activation_present and activation_only and not was_active:
            return {
                "event": "activated_only",
                "normalized": normalized,
            }

        if activation_present and activation_only and was_active:
            return {"event": "ignore", "normalized": normalized}

        return {"event": "error", "normalized": normalized}


def self_test():
    router = CommandRouter()
    tests = [
        ("Джарвис", "activated_only"),
        ("Привет джарвис", "ignore"),
        ("Привет, Джарвис открой ютуб", "command"),
        ("я устал открой ютуб", "command"),
        ("Спасибо джарвис", "deactivated"),
        ("Открой ютуб", "ignore"),
        ("джарвис найди как готовить картошку", "command"),
        ("джарвис бла бла бла", "error"),
    ]

    results = []
    for phrase, expected in tests:
        result = router.process(phrase)
        results.append(
            {
                "phrase": phrase,
                "expected": expected,
                "got": result.get("event"),
                "ok": result.get("event") == expected,
            }
        )
    return results
