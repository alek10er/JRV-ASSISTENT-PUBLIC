import os
import random
import subprocess
import sys
import threading
import time
import uuid

import config_manager

IS_WINDOWS = os.name == "nt"


def _project_root():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))


def _candidate_sound_dirs():
    dirs = []

    base_root = _project_root()
    dirs.append(os.path.join(base_root, "Sounds"))

    exe_dir = os.path.dirname(os.path.abspath(sys.executable))
    dirs.append(os.path.join(exe_dir, "Sounds"))
    dirs.append(os.path.join(exe_dir, "_internal", "Sounds"))

    meipass = getattr(sys, "_MEIPASS", "")
    if meipass:
        dirs.append(os.path.join(meipass, "Sounds"))
        dirs.append(os.path.join(meipass, "_internal", "Sounds"))

    seen = set()
    out = []
    for item in dirs:
        key = os.path.normcase(os.path.normpath(item))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def _default_sound_dir():
    for item in _candidate_sound_dirs():
        if os.path.isdir(item):
            return item
    return os.path.join(_project_root(), "Sounds")


SOUND_DIR = _default_sound_dir()

SUCCESS_SOUNDS = [
    "SCF.wav",
    "SCF 1.wav",
    "SCF 2.wav",
    "SCF 3.wav",
    "SCF 4.wav",
]

DEFAULT_SOUNDS = {
    "activation": ["Hello.wav"],
    "deactivation": ["turn off.wav"],
    "error": ["ERROR.wav"],
    "success": SUCCESS_SOUNDS[:],
}

_sounds_by_group = DEFAULT_SOUNDS.copy()
_play_error_enabled = True

_last_error_at = 0.0
_error_cooldown_sec = 1.0

def _sound_path(name):
    return os.path.join(SOUND_DIR, name)


def _resolve_sound_path(name):
    if not name:
        return None
    value = str(name).strip()
    if not value:
        return None

    # Support UI-style project-relative forms like "/Sounds/Hello.wav".
    normalized = value.replace("/", os.sep).replace("\\", os.sep)
    stripped = normalized.lstrip("\\/")
    sounds_prefix = f"Sounds{os.sep}"
    if stripped.lower().startswith(sounds_prefix.lower()):
        rel = stripped[len(sounds_prefix):]
        for sound_dir in _candidate_sound_dirs():
            candidate = os.path.join(sound_dir, rel)
            if os.path.exists(candidate):
                return candidate
        return os.path.join(SOUND_DIR, rel)

    if os.path.isabs(value):
        return value

    for sound_dir in _candidate_sound_dirs():
        candidate = os.path.join(sound_dir, value)
        if os.path.exists(candidate):
            return candidate

    # Legacy fallback: settings may store only file name.
    base_name = os.path.basename(value)
    return _sound_path(base_name)


def _normalize_sound_list(items):
    if not isinstance(items, list):
        return []
    out = []
    for item in items:
        value = str(item).strip()
        if value:
            out.append(value)
    return out


def _play_windows(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".wav":
        try:
            import winsound

            winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC)
            return True
        except Exception:
            pass

    # MCI fallback supports more formats in packaged builds (mp3 and others).
    if _play_windows_mci(path):
        return True

    # Last fallback for wav via PowerShell.
    if ext == ".wav":
        try:
            escaped = path.replace("'", "''")
            cmd = (
                "Add-Type -AssemblyName System;"
                "$p = New-Object System.Media.SoundPlayer;"
                f"$p.SoundLocation='{escaped}';"
                "$p.Play();"
            )
            subprocess.Popen(
                ["powershell", "-NoProfile", "-Command", cmd],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return True
        except Exception:
            return False
    return False


def _play_windows_mci(path):
    try:
        import ctypes

        winmm = ctypes.windll.winmm

        def _send(command):
            return winmm.mciSendStringW(command, None, 0, None) == 0

        quoted_path = path.replace('"', '""')
        alias = f"jarvis_{uuid.uuid4().hex}"
        media_type = "waveaudio" if path.lower().endswith(".wav") else "mpegvideo"

        if not _send(f'open "{quoted_path}" type {media_type} alias {alias}'):
            if not _send(f'open "{quoted_path}" alias {alias}'):
                return False
        if not _send(f"play {alias}"):
            _send(f"close {alias}")
            return False

        def _cleanup():
            time.sleep(20)
            try:
                _send(f"close {alias}")
            except Exception:
                pass

        threading.Thread(target=_cleanup, daemon=True).start()
        return True
    except Exception:
        return False


def play_sound(name):
    path = _resolve_sound_path(name)
    if not path:
        return False
    if not os.path.exists(path):
        return False
    if IS_WINDOWS:
        return _play_windows(path)
    return False


def reload_settings():
    global _sounds_by_group, _play_error_enabled
    settings = config_manager.load_settings()
    sounds = settings.get("sounds", {}) if isinstance(settings, dict) else {}
    merged = {}
    for group, default_list in DEFAULT_SOUNDS.items():
        configured = _normalize_sound_list(sounds.get(group))
        merged[group] = configured if configured else default_list[:]
    _sounds_by_group = merged
    _play_error_enabled = bool(settings.get("play_error_sound", True))


def _play_from_group(group, fallback):
    choices = _sounds_by_group.get(group) or fallback
    valid = [name for name in choices if os.path.exists(_resolve_sound_path(name) or "")]
    if not valid:
        return False
    return play_sound(random.choice(valid))


def play_hello():
    return _play_from_group("activation", DEFAULT_SOUNDS["activation"])


def play_turn_off():
    return _play_from_group("deactivation", DEFAULT_SOUNDS["deactivation"])


def play_error():
    global _last_error_at
    if not _play_error_enabled:
        return False
    now = time.monotonic()
    if now - _last_error_at < _error_cooldown_sec:
        return False
    _last_error_at = now
    return _play_from_group("error", DEFAULT_SOUNDS["error"])


def play_success():
    return _play_from_group("success", DEFAULT_SOUNDS["success"])


reload_settings()
