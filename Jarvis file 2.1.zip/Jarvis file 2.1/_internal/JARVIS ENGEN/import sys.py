import os
import runpy
import socket
import subprocess
import sys
import time
import urllib.request
from datetime import datetime

APP_MAIN_EXE = "JARVIS_MAIN.exe"
MAIN_MODE_ARG = "--run-main"
RUNTIME_DIR = os.path.join(os.getenv("LOCALAPPDATA") or os.getcwd(), "JARVIS_AI")
RUNTIME_LOG = os.path.join(RUNTIME_DIR, "runtime.log")


def _log(message):
    try:
        os.makedirs(RUNTIME_DIR, exist_ok=True)
        with open(RUNTIME_LOG, "a", encoding="utf-8") as f:
            stamp = datetime.now().isoformat(sep=" ", timespec="seconds")
            f.write(f"[{stamp}] [loader] {message}\n")
    except Exception:
        pass


def _show_error_dialog(message, title="JARVIS AI"):
    try:
        import ctypes

        ctypes.windll.user32.MessageBoxW(None, message, title, 0x10)
    except Exception:
        pass


def check_internet(timeout_sec=4):
    dns_ok = False
    for host in (("1.1.1.1", 53), ("8.8.8.8", 53)):
        try:
            sock = socket.create_connection(host, timeout=3)
            sock.close()
            dns_ok = True
            break
        except Exception:
            continue

    checks = [
        ("http://www.msftconnecttest.com/connecttest.txt", 200, b"Microsoft Connect Test"),
        ("http://clients3.google.com/generate_204", 204, b""),
    ]
    for url, expected_status, marker in checks:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
                status = getattr(resp, "status", resp.getcode())
                data = resp.read(64)
            if status == expected_status and (not marker or marker in data):
                return True, "Internet: OK"
        except Exception:
            continue

    if dns_ok:
        return False, "Internet: no web access"
    return False, "Internet: no connection"


def resolve_engine_dir():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        base_dir,
        os.path.join(base_dir, "JARVIS ENGEN"),
        os.path.join(os.path.dirname(base_dir), "JARVIS ENGEN"),
    ]
    for candidate in candidates:
        if os.path.exists(os.path.join(candidate, "import webview.py")):
            return candidate
    return base_dir


def _get_main_script_path():
    candidates = []
    if getattr(sys, "frozen", False):
        meipass = getattr(sys, "_MEIPASS", "")
        if meipass:
            candidates.append(os.path.join(meipass, "JARVIS ENGEN", "import webview.py"))
        candidates.append(os.path.join(os.path.dirname(sys.executable), "JARVIS ENGEN", "import webview.py"))
    else:
        engine_dir = resolve_engine_dir()
        candidates.append(os.path.join(engine_dir, "import webview.py"))

    for path in candidates:
        if path and os.path.exists(path):
            return path
    return None


def _resolve_main_target():
    if getattr(sys, "frozen", False):
        base_dir = os.path.dirname(sys.executable)
        exe_target = os.path.join(base_dir, APP_MAIN_EXE)
        if os.path.exists(exe_target):
            return "exe", exe_target
        script_target = _get_main_script_path()
        if script_target:
            return "self", script_target
    script_target = _get_main_script_path()
    return "script", script_target or ""


def _run_main_inline():
    script_path = _get_main_script_path()
    if not script_path:
        _log("main inline script path not found")
        return 2

    script_dir = os.path.dirname(script_path)
    if script_dir and script_dir not in sys.path:
        sys.path.insert(0, script_dir)

    _log(f"run main inline: {script_path}")
    runpy.run_path(script_path, run_name="__main__")
    return 0


def launch_main_app(retries=1, start_wait_sec=1.2):
    target_mode, target = _resolve_main_target()
    if not os.path.exists(target):
        return False, "Main target not found"

    last_err = ""
    for _ in range(retries + 1):
        try:
            cmd = [sys.executable, target]
            cwd = os.path.dirname(target)
            if target_mode == "exe":
                cmd = [target]
            elif target_mode == "self":
                cmd = [sys.executable, MAIN_MODE_ARG]
                cwd = os.path.dirname(sys.executable)

            _log(f"launch main: mode={target_mode} cmd={cmd}")
            proc = subprocess.Popen(cmd, cwd=cwd)
        except Exception as e:
            last_err = str(e)
            _log(f"launch main exception: {last_err}")
            continue

        time.sleep(start_wait_sec)
        if proc.poll() is None:
            _log("launch main: process is running")
            return True, ""

        last_err = f"Main process exited with code {proc.returncode}"
        _log(last_err)

    return False, last_err or "Failed to launch main app"


def main():
    if MAIN_MODE_ARG in sys.argv:
        sys.argv = [arg for arg in sys.argv if arg != MAIN_MODE_ARG]
        try:
            return _run_main_inline()
        except Exception as e:
            _log(f"fatal in main inline: {e}")
            return 1

    internet_ok, internet_msg = check_internet()
    _log(f"internet check: {internet_msg}")
    if not internet_ok:
        _show_error_dialog(
            "Internet connection is required to start JARVIS.\nPlease connect and run again.",
            "JARVIS AI",
        )
        _log("fatal launch error: internet is required")
        return 1

    started, err = launch_main_app(retries=1)
    if not started:
        _log(f"fatal launch error: {err}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
