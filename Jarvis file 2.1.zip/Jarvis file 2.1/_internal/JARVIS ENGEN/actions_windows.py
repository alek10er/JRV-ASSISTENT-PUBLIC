﻿import ctypes
import ctypes.wintypes
import os
import subprocess
import urllib.parse
import webbrowser


IS_WINDOWS = os.name == "nt"

if IS_WINDOWS:
    user32 = ctypes.windll.user32


def _get_target_hwnd():
    if not IS_WINDOWS:
        return None
    point = ctypes.wintypes.POINT()
    hwnd = None
    if user32.GetCursorPos(ctypes.byref(point)):
        hwnd = user32.WindowFromPoint(point)
    if not hwnd:
        hwnd = user32.GetForegroundWindow()
    if hwnd:
        GA_ROOT = 2
        hwnd = user32.GetAncestor(hwnd, GA_ROOT) or hwnd
    return hwnd


def open_url(url):
    try:
        ok = webbrowser.open(url)
        return ok, "Opening URL"
    except Exception as e:
        return False, f"Open URL error: {e}"


def search_web(query):
    if not query:
        return False, "Empty search query"
    url = "https://www.google.com/search?q=" + urllib.parse.quote_plus(query)
    return open_url(url)


def minimize_window():
    if not IS_WINDOWS:
        return False, "Windows only command"
    hwnd = _get_target_hwnd()
    if not hwnd:
        return False, "Window not found"
    SW_MINIMIZE = 6
    user32.ShowWindow(hwnd, SW_MINIMIZE)
    return True, "Minimizing window"


def close_window():
    if not IS_WINDOWS:
        return False, "Windows only command"
    hwnd = _get_target_hwnd()
    if not hwnd:
        return False, "Window not found"
    WM_CLOSE = 0x0010
    user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)
    return True, "Closing window"


def show_desktop():
    if not IS_WINDOWS:
        return False, "Windows only command"
    VK_LWIN = 0x5B
    VK_D = 0x44
    KEYEVENTF_KEYUP = 0x0002

    user32.keybd_event(VK_LWIN, 0, 0, 0)
    user32.keybd_event(VK_D, 0, 0, 0)
    user32.keybd_event(VK_D, 0, KEYEVENTF_KEYUP, 0)
    user32.keybd_event(VK_LWIN, 0, KEYEVENTF_KEYUP, 0)
    return True, "Showing desktop"


def open_program(path):
    if not path:
        return False, "Program path is empty"

    raw = str(path).strip().strip('"').strip("'")
    if not raw:
        return False, "Program path is empty"

    if raw.lower().startswith(("http://", "https://")):
        return open_url(raw)

    expanded = os.path.expandvars(os.path.expanduser(raw))
    full_path = expanded if os.path.isabs(expanded) else os.path.abspath(expanded)

    if not os.path.exists(full_path):
        return False, "Program file not found"

    try:
        if IS_WINDOWS:
            # Uses the associated application:
            # exe/bat/cmd/ps1/scripts + media files (mp3/mp4/wav, etc.).
            os.startfile(full_path)  # type: ignore[attr-defined]
            return True, f"Opening: {os.path.basename(full_path) or full_path}"

        if os.path.isdir(full_path):
            subprocess.Popen(["xdg-open", full_path])
            return True, f"Opening: {os.path.basename(full_path) or full_path}"

        subprocess.Popen([full_path], cwd=os.path.dirname(full_path) or None)
        return True, f"Starting program: {os.path.basename(full_path)}"
    except Exception as e:
        # Extra fallback for script-like files on Windows.
        if IS_WINDOWS:
            ext = os.path.splitext(full_path)[1].lower()
            try:
                if ext in {".bat", ".cmd"}:
                    subprocess.Popen(
                        ["cmd", "/c", full_path],
                        cwd=os.path.dirname(full_path) or None,
                        creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0),
                    )
                    return True, f"Starting script: {os.path.basename(full_path)}"
                if ext == ".ps1":
                    subprocess.Popen(
                        [
                            "powershell",
                            "-NoProfile",
                            "-ExecutionPolicy",
                            "Bypass",
                            "-File",
                            full_path,
                        ],
                        cwd=os.path.dirname(full_path) or None,
                        creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0),
                    )
                    return True, f"Starting script: {os.path.basename(full_path)}"
            except Exception:
                pass
        return False, f"Program start error: {e}"


def press_hotkeys(keys):
    if not IS_WINDOWS:
        return False, "Windows only command"
    if not keys:
        return False, "Hotkey list is empty"

    key_map = {
        "CTRL": 0x11,
        "CONTROL": 0x11,
        "SHIFT": 0x10,
        "ALT": 0x12,
        "WIN": 0x5B,
        "META": 0x5B,
        "ENTER": 0x0D,
        "TAB": 0x09,
        "ESC": 0x1B,
        "ESCAPE": 0x1B,
        "SPACE": 0x20,
        "BACKSPACE": 0x08,
        "DELETE": 0x2E,
        "HOME": 0x24,
        "END": 0x23,
        "PAGEUP": 0x21,
        "PAGEDOWN": 0x22,
        "UP": 0x26,
        "DOWN": 0x28,
        "LEFT": 0x25,
        "RIGHT": 0x27,
    }

    for i in range(1, 13):
        key_map[f"F{i}"] = 0x6F + i

    for c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        key_map[c] = ord(c)
    for d in "0123456789":
        key_map[d] = ord(d)

    aliases = {
        "CMD": "WIN",
        "WINDOWS": "WIN",
        "RETURN": "ENTER",
        "PGUP": "PAGEUP",
        "PGDN": "PAGEDOWN",
    }

    vk_codes = []
    for token in keys:
        t = str(token or "").strip().upper()
        t = aliases.get(t, t)
        vk = key_map.get(t)
        if vk is None:
            return False, f"Unknown key: {token}"
        vk_codes.append(vk)

    KEYEVENTF_KEYUP = 0x0002
    try:
        for vk in vk_codes:
            user32.keybd_event(vk, 0, 0, 0)
        for vk in reversed(vk_codes):
            user32.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)
        return True, "Hotkeys sent"
    except Exception as e:
        return False, f"Hotkey send error: {e}"
