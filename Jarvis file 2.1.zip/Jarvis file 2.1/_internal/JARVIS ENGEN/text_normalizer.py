import re


_PUNCT_RE = re.compile(r"[^a-zа-я0-9\s]", re.IGNORECASE)
_SPACE_RE = re.compile(r"\s+")


def normalize_text(text):
    if not text:
        return ""
    text = str(text).lower().replace("ё", "е")
    text = _PUNCT_RE.sub(" ", text)
    text = _SPACE_RE.sub(" ", text).strip()
    return text


def tokenize(text):
    normalized = normalize_text(text)
    if not normalized:
        return []
    return normalized.split(" ")

