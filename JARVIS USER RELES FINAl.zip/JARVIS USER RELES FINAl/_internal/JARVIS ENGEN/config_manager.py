import json
import os


DEFAULT_ACTIVATION = [
    "джарвис",
    "привет джарвис",
]

DEFAULT_DEACTIVATION = [
    "спасибо джарвис",
    "пока джарвис",
]

DEFAULT_COMMANDS = [
    {
        "id": "open_youtube",
        "type": "phrase",
        "action": "open_url",
        "url": "https://www.youtube.com",
        "phrases": [
            "открой ютуб",
            "открыть ютуб",
            "ютуб",
            "youtube",
            "открой youtube",
            "открыть youtube",
        ],
    },
    {
        "id": "search_web",
        "type": "pattern",
        "action": "search_web",
        "phrases": [
            "найди",
            "поиск",
            "загугли",
        ],
    },
    {
        "id": "minimize_window",
        "type": "phrase",
        "action": "minimize_window",
        "phrases": [
            "сверни окно",
            "свернуть окно",
            "минимизируй окно",
            "сверни",
            "свернуть",
        ],
    },
    {
        "id": "close_window",
        "type": "phrase",
        "action": "close_window",
        "phrases": [
            "закрой окно",
            "закрыть окно",
            "закрой",
            "закрыть",
        ],
    },
    {
        "id": "show_desktop",
        "type": "phrase",
        "action": "show_desktop",
        "phrases": [
            "сверни все окна",
            "свернуть все окна",
            "покажи рабочий стол",
            "показать рабочий стол",
        ],
    },
]

DEFAULT_SETTINGS = {
    "voice": "Default",
    "play_error_sound": True,
    "show_console": True,
    "microphone": "Default Microphone",
    "output_device": "Default Output",
    "auto_update_soon": False,
    "analytics_enabled": False,
    "sounds": {
        "activation": ["Hello.wav"],
        "deactivation": ["turn off.wav"],
        "error": ["ERROR.wav"],
        "success": [
            "SCF.wav",
            "SCF 2.wav",
            "SCF 3.wav",
            "SCF 4.wav",
        ],
    },
}


def get_project_root():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))


def get_configs_dir():
    return os.path.join(get_project_root(), "configs")


def _ensure_file(path, data):
    if os.path.exists(path):
        return
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def ensure_configs():
    configs_dir = get_configs_dir()
    os.makedirs(configs_dir, exist_ok=True)
    _ensure_file(os.path.join(configs_dir, "activation_phrases.json"), DEFAULT_ACTIVATION)
    _ensure_file(os.path.join(configs_dir, "deactivation_phrases.json"), DEFAULT_DEACTIVATION)
    _ensure_file(os.path.join(configs_dir, "commands.json"), DEFAULT_COMMANDS)
    _ensure_file(os.path.join(configs_dir, "settings.json"), DEFAULT_SETTINGS)


def _load_json(path, fallback):
    ensure_configs()
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return fallback


def load_activation_phrases():
    return _load_json(
        os.path.join(get_configs_dir(), "activation_phrases.json"),
        DEFAULT_ACTIVATION,
    )


def load_deactivation_phrases():
    return _load_json(
        os.path.join(get_configs_dir(), "deactivation_phrases.json"),
        DEFAULT_DEACTIVATION,
    )


def load_commands():
    return _load_json(
        os.path.join(get_configs_dir(), "commands.json"),
        DEFAULT_COMMANDS,
    )


def save_commands(commands):
    ensure_configs()
    path = os.path.join(get_configs_dir(), "commands.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(commands, f, ensure_ascii=False, indent=2)


def save_activation_phrases(phrases):
    ensure_configs()
    path = os.path.join(get_configs_dir(), "activation_phrases.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(phrases, f, ensure_ascii=False, indent=2)


def save_deactivation_phrases(phrases):
    ensure_configs()
    path = os.path.join(get_configs_dir(), "deactivation_phrases.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(phrases, f, ensure_ascii=False, indent=2)


def load_settings():
    return _load_json(
        os.path.join(get_configs_dir(), "settings.json"),
        DEFAULT_SETTINGS,
    )


def save_settings(settings):
    ensure_configs()
    path = os.path.join(get_configs_dir(), "settings.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(settings, f, ensure_ascii=False, indent=2)
