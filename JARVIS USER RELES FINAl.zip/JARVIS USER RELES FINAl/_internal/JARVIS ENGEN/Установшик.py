import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, messagebox
import requests
import platform
import hashlib
import threading
from datetime import datetime
import random
import sys
import os
import json
import zipfile
import io
import shutil
from pathlib import Path
import subprocess
import uuid
import time

# Настройка внешнего вида customtkinter
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

# Конфигурация Supabase
SUPABASE_URL = "https://hikpmunrcmlqgjnzkmhd.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhpa3BtdW5yY21scWdqbnprbWhkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgxNTE4OTUsImV4cCI6MjA4MzcyNzg5NX0.FSDQLHcglva97FWOHcvXVFGn9lJC0nHGxbmnHpiDL8k"
TABLE_NAME = "users"

# Конфигурация установки
GITHUB_REPO_URL = "https://github.com/alek10er/JRV-ASSISTENT-PUBLIC"
EXE_DOWNLOAD_URL = "https://github.com/alek10er/JRV-ASSISTENT-PUBLIC/releases/download/RU-ASISTENT/JarvisAssistant.V6.PUBLIC.exe"

# Глобальные тексты для синхронизации между окнами
INSTALLATION_TEXTS = {
    "english": {
        "window_title": "J.A.R.V.I.S. Installation",
        "title": "JARVIS INSTALLATION",
        "welcome": "Welcome, {}!",
        "path_label": "Installation Path:",
        "browse": "Browse...",
        "install": "START INSTALLATION",
        "progress_title": "Installation Progress",
        "progress_creating": "Creating JARVIS directory...",
        "progress_downloading_exe": "Downloading JARVIS executable...",
        "progress_downloading_files": "Downloading repository files...",
        "progress_configs": "Downloading configuration files...",
        "progress_model": "Downloading VOSK model...",
        "progress_finalizing": "Finalizing installation...",
        "progress_completed": "Installation completed successfully!",
        "launch": "🚀 LAUNCH JARVIS",
        "open_folder": "📁 OPEN INSTALLATION FOLDER",
        "folder_dialog_title": "Select JARVIS Installation Folder",
        "error_no_path": "Please select installation path",
        "error_install_failed": "Installation failed: {}",
        "log_created_dir": "Created JARVIS directory",
        "log_downloading": "Downloading: {}",
        "log_downloaded": "Downloaded {} of {} files",
        "log_downloading_config": "Downloading config: {}",
        "log_downloading_model": "Downloading model file: {}",
        "log_finalizing": "Finalizing installation...",
        "log_completed": "Installation completed successfully!",
        "log_launched": "JARVIS launched successfully!",
        "log_folder_opened": "Installation folder opened",
        "error_launch": "JARVIS executable not found!",
        "error_folder": "Installation folder not found!",
        "readme_title": "JARVIS Installation",
        "readme_installed_for": "Installed for: {}",
        "readme_date": "Installation date: {}",
        "readme_location": "Location: {}",
        "readme_run": "To start JARVIS, run: JarvisAssistant.V6.PUBLIC.exe"
    },
    "russian": {
        "window_title": "Установка J.A.R.V.I.S.",
        "title": "УСТАНОВКА JARVIS",
        "welcome": "Добро пожаловать, {}!",
        "path_label": "Путь установки:",
        "browse": "Обзор...",
        "install": "НАЧАТЬ УСТАНОВКУ",
        "progress_title": "Прогресс установки",
        "progress_creating": "Создание директории JARVIS...",
        "progress_downloading_exe": "Загрузка исполняемого файла JARVIS...",
        "progress_downloading_files": "Загрузка файлов репозитория...",
        "progress_configs": "Загрузка конфигурационных файлов...",
        "progress_model": "Загрузка модели VOSK...",
        "progress_finalizing": "Завершение установки...",
        "progress_completed": "Установка успешно завершена!",
        "launch": "🚀 ЗАПУСТИТЬ JARVIS",
        "open_folder": "📁 ОТКРЫТЬ ПАПКУ УСТАНОВКИ",
        "folder_dialog_title": "Выберите папку для установки JARVIS",
        "error_no_path": "Пожалуйста, выберите путь установки",
        "error_install_failed": "Ошибка установки: {}",
        "log_created_dir": "Создана директория JARVIS",
        "log_downloading": "Загрузка: {}",
        "log_downloaded": "Загружено {} из {} файлов",
        "log_downloading_config": "Загрузка конфигурации: {}",
        "log_downloading_model": "Загрузка файла модели: {}",
        "log_finalizing": "Завершение установки...",
        "log_completed": "Установка успешно завершена!",
        "log_launched": "JARVIS успешно запущен!",
        "log_folder_opened": "Папка установки открыта",
        "error_launch": "Исполняемый файл JARVIS не найден!",
        "error_folder": "Папка установки не найдена!",
        "readme_title": "Установка JARVIS",
        "readme_installed_for": "Установлено для: {}",
        "readme_date": "Дата установки: {}",
        "readme_location": "Расположение: {}",
        "readme_run": "Для запуска JARVIS, запустите: JarvisAssistant.V6.PUBLIC.exe"
    }
}

class StarfieldCanvas(ctk.CTkCanvas):
    """Canvas с анимацией звездного неба"""
    def __init__(self, master, width, height, **kwargs):
        super().__init__(master, **kwargs)
        self.width = width
        self.height = height
        self.star_count = 60
        self.frame_ms = 50
        self.stars = []
        self._after_id = None
        self._running = True
        self.create_stars(self.star_count)
        self.animate()
        self.bind("<Configure>", self.on_resize)
        self.bind("<Destroy>", self._on_destroy, add="+")
    
    def create_stars(self, count):
        """Создание звезд"""
        for _ in range(count):
            x = random.randint(0, self.width)
            y = random.randint(0, self.height)
            size = random.uniform(0.5, 2.5)
            speed = random.uniform(0.1, 0.8)
            brightness = random.randint(100, 220)
            
            star = self.create_oval(
                x, y, x + size, y + size,
                fill=f"#{brightness:02x}{brightness:02x}{brightness:02x}",
                outline=""
            )
            
            self.stars.append({
                "id": star,
                "x": x,
                "y": y,
                "size": size,
                "speed": speed,
                "brightness": brightness,
                "twinkle_speed": random.uniform(0.01, 0.03),
                "twinkle_dir": 1
            })
    
    def animate(self):
        """Анимация звезд"""
        if not self._running or not self.winfo_exists():
            return
        for star in self.stars:
            # Движение звезд
            star["x"] += star["speed"]
            if star["x"] > self.width:
                star["x"] = 0
                star["y"] = random.randint(0, self.height)
            
            # Мерцание
            star["brightness"] += star["twinkle_speed"] * star["twinkle_dir"]
            if star["brightness"] > 220 or star["brightness"] < 100:
                star["twinkle_dir"] *= -1
            
            # Обновление позиции и цвета
            self.coords(
                star["id"],
                star["x"], star["y"],
                star["x"] + star["size"], star["y"] + star["size"]
            )
            
            brightness_int = int(star["brightness"])
            color = f"#{brightness_int:02x}{brightness_int:02x}{brightness_int:02x}"
            self.itemconfig(star["id"], fill=color)
        
        self._after_id = self.after(self.frame_ms, self.animate)

    def on_resize(self, event):
        """Обновление размеров холста"""
        self.width = event.width
        self.height = event.height

    def stop_animation(self):
        self._running = False
        if self._after_id is not None:
            try:
                self.after_cancel(self._after_id)
            except Exception:
                pass
            self._after_id = None

    def _on_destroy(self, _event=None):
        self.stop_animation()

class ModernActivationApp:
    def __init__(self):
        # Инициализация главного окна
        self.root = ctk.CTk()
        self.root.title("J.A.R.V.I.S. Activation")
        
        # Настройка темы
        ctk.set_appearance_mode("dark")
        
        # Размер окна и центрирование
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        self.width = 920
        self.height = 600
        
        pos_x = (screen_width - self.width) // 2
        pos_y = (screen_height - self.height) // 2
        
        self.root.geometry(f"{self.width}x{self.height}+{pos_x}+{pos_y}")
        self.root.minsize(self.width, self.height)
        self.root.resizable(False, False)
        
        self.colors = {
            "bg": "#05070d",
            "panel": "#0f141b",
            "panel_border": "#1f2732",
            "accent": "#3b82f6",
            "accent_hover": "#2563eb",
            "title": "#f8fafc",
            "subtitle": "#9aa4b2",
            "muted": "#7b8794",
            "muted_dark": "#4b5563",
            "input_bg": "#0b0f14",
            "input_border": "#233042",
            "button_text": "#f8fafc",
            "status_ready": "#7b8794",
        }
        self.lang_animating = False
        self._last_log_time = 0.0
        self._last_log_percent = -1
        self._log_interval = 0.5
        self._log_percent_step = 5
        
        # Словари для текстов
        self.texts = {
            "english": {
                "title": "JARVIS BY VOICETECH",
                "subtitle": "AI Assistant System",
                "enter_code": "Enter activation code",
                "submit": "ACTIVATE SYSTEM",
                "welcome": "Welcome back, {}",
                "loading": "Verifying credentials...",
                "error_incorrect": "Invalid activation key",
                "error_hwid": "Device authorization failed",
                "error_internet": "No internet connection",
                "error_unknown": "System error occurred",
                "select_lang": "LANGUAGE",
                "status_ready": "Ready for activation",
                "copyright": "© 2026 VoiceTech Systems. All rights reserved."
            },
            "russian": {
                "title": "JARVIS BY VOICETECH",
                "subtitle": "Система ИИ-помощника",
                "enter_code": "Введите код активации",
                "submit": "АКТИВИРОВАТЬ СИСТЕМУ",
                "welcome": "С возвращением, {}",
                "loading": "Проверка учетных данных...",
                "error_incorrect": "Неверный ключ активации",
                "error_hwid": "Ошибка авторизации устройства",
                "error_internet": "Нет подключения к интернету",
                "error_unknown": "Произошла системная ошибка",
                "select_lang": "ЯЗЫК",
                "status_ready": "Готово к активации",
                "copyright": "© 2026 VoiceTech Systems. Все права защищены."
            }
        }
        
        self.current_lang = "english"
        self._next_install_user = None
        self._closed = False
        
        # Флаг для предотвращения многократных нажатий
        self.activation_in_progress = False
        
        # Переменная для отслеживания вставки текста
        self.paste_in_progress = False
        
        # Создание интерфейса
        self.create_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.on_window_close)
        
        # Запуск
        self.root.mainloop()
        if self._next_install_user:
            install_window = InstallationWindow(self._next_install_user, self.current_lang)
            install_window.run()
    
    def create_ui(self):
        """Создание пользовательского интерфейса"""
        # Фрейм для звездного фона
        self.bg_frame = ctk.CTkFrame(self.root, fg_color=self.colors["bg"])
        self.bg_frame.pack(fill="both", expand=True)
        
        # Canvas с звездами
        self.star_canvas = StarfieldCanvas(
            self.bg_frame,
            width=self.width,
            height=self.height,
            bg=self.colors["bg"],
            highlightthickness=0
        )
        self.star_canvas.pack(fill="both", expand=True)
        
        # Карточка-контейнер
        self.card_frame = ctk.CTkFrame(
            self.star_canvas,
            fg_color=self.colors["panel"],
            border_color=self.colors["panel_border"],
            border_width=1,
            corner_radius=24
        )
        self.card_frame.place(relx=0.5, rely=0.5, anchor="center")
        
        # Основной контейнер
        self.main_container = ctk.CTkFrame(
            self.card_frame,
            fg_color="transparent"
        )
        self.main_container.pack(padx=50, pady=40)
        
        # Заголовок
        self.title_label = ctk.CTkLabel(
            self.main_container,
            text=self.texts[self.current_lang]["title"],
            font=("Montserrat", 36, "bold"),
            text_color=self.colors["title"]
        )
        self.title_label.pack(pady=(0, 5))
        
        # Подзаголовок
        self.subtitle_label = ctk.CTkLabel(
            self.main_container,
            text=self.texts[self.current_lang]["subtitle"],
            font=("Montserrat", 14),
            text_color=self.colors["subtitle"]
        )
        self.subtitle_label.pack(pady=(0, 40))
        
        # Фрейм для выбора языка
        self.lang_frame = ctk.CTkFrame(
            self.main_container,
            fg_color="#121822",
            corner_radius=12
        )
        self.lang_frame.pack(pady=(0, 30))
        
        self.lang_label = ctk.CTkLabel(
            self.lang_frame,
            text=self.texts[self.current_lang]["select_lang"],
            font=("Montserrat", 11, "bold"),
            text_color=self.colors["muted"]
        )
        self.lang_label.pack(side="left", padx=(15, 10), pady=10)
        
        # Кнопки переключения языка
        self.lang_btn_frame = ctk.CTkFrame(
            self.lang_frame,
            fg_color="transparent"
        )
        self.lang_btn_frame.pack(side="left", padx=(0, 15), pady=10)
        
        self.eng_btn = ctk.CTkButton(
            self.lang_btn_frame,
            text="EN",
            width=50,
            height=30,
            font=("Montserrat", 10, "bold"),
            fg_color=self.colors["accent"] if self.current_lang == "english" else "#1c2530",
            hover_color=self.colors["accent_hover"],
            text_color=self.colors["button_text"],
            command=lambda: self.set_language("english")
        )
        self.eng_btn.pack(side="left", padx=(0, 5))
        
        self.rus_btn = ctk.CTkButton(
            self.lang_btn_frame,
            text="RU",
            width=50,
            height=30,
            font=("Montserrat", 10, "bold"),
            fg_color=self.colors["accent"] if self.current_lang == "russian" else "#1c2530",
            hover_color=self.colors["accent_hover"],
            text_color=self.colors["button_text"],
            command=lambda: self.set_language("russian")
        )
        self.rus_btn.pack(side="left")
        
        # Фрейм для поля ввода
        self.entry_frame = ctk.CTkFrame(
            self.main_container,
            fg_color="transparent"
        )
        self.entry_frame.pack(pady=(0, 20))
        
        # Поле ввода кода (используем кастомный Entry для исправления русской раскладки)
        self.code_entry = self.create_fixed_entry()
        
        # Кнопка активации
        self.activate_btn = ctk.CTkButton(
            self.main_container,
            text=self.texts[self.current_lang]["submit"],
            width=350,
            height=50,
            font=("Montserrat", 14, "bold"),
            fg_color=self.colors["accent"],
            hover_color=self.colors["accent_hover"],
            corner_radius=10,
            text_color=self.colors["button_text"],
            command=self.activate
        )
        self.activate_btn.pack(pady=(0, 20))
        
        # Статус
        self.status_label = ctk.CTkLabel(
            self.main_container,
            text=self.texts[self.current_lang]["status_ready"],
            font=("Montserrat", 12),
            text_color=self.colors["status_ready"]
        )
        self.status_label.pack()
        
        # Копирайт
        self.copyright_label = ctk.CTkLabel(
            self.star_canvas,
            text=self.texts[self.current_lang]["copyright"],
            font=("Montserrat", 10),
            text_color=self.colors["muted_dark"]
        )
        self.copyright_label.place(relx=0.5, rely=0.95, anchor="center")
        
        # Градиентная линия (декоративная)
        self.create_gradient_line()
        
        # Привязка событий для обработки вставки
        self.setup_paste_handling()
    
    def create_fixed_entry(self):
        """Создание поля ввода с исправленной поддержкой вставки"""
        # Создаем стандартный CTkEntry
        entry = ctk.CTkEntry(
            self.entry_frame,
            width=350,
            height=50,
            placeholder_text=self.texts[self.current_lang]["enter_code"],
            placeholder_text_color=self.colors["muted"],
            font=("Montserrat", 14),
            text_color=self.colors["title"],
            fg_color=self.colors["input_bg"],
            border_color=self.colors["input_border"],
            corner_radius=10
        )
        entry.pack()
        
        # Получаем доступ к внутреннему Tkinter Entry
        self.tk_entry = entry._entry
        
        # Привязываем обработчики событий
        self.tk_entry.bind("<Control-v>", self.on_paste_ctrl_v)
        self.tk_entry.bind("<Control-V>", self.on_paste_ctrl_v)
        self.tk_entry.bind("<Button-3>", self.on_right_click)  # Правая кнопка мыши
        self.tk_entry.bind("<Key>", self.on_key_press)  # Обработка всех клавиш
        
        return entry
    
    def setup_paste_handling(self):
        """Настройка обработки вставки для всего приложения"""
        # Создаем меню для правой кнопки мыши
        self.context_menu = tk.Menu(self.root, tearoff=0)
        self.context_menu.add_command(label="Вставить", command=self.paste_from_menu)
        self.context_menu.add_command(label="Вырезать", command=self.cut_from_menu)
        self.context_menu.add_command(label="Копировать", command=self.copy_from_menu)
        
        # Привязываем меню к полю ввода
        self.tk_entry.bind("<Button-3>", self.show_context_menu)
    
    def on_paste_ctrl_v(self, event):
        """Обработка Ctrl+V"""
        try:
            # Получаем текст из буфера обмена
            clipboard_text = self.root.clipboard_get()
            
            # Вставляем текст в поле ввода
            current_text = self.code_entry.get()
            cursor_pos = self.tk_entry.index(tk.INSERT)
            
            # Вставляем текст на позицию курсора
            new_text = current_text[:cursor_pos] + clipboard_text + current_text[cursor_pos:]
            self.code_entry.delete(0, tk.END)
            self.code_entry.insert(0, new_text)
            
            # Перемещаем курсор после вставленного текста
            new_cursor_pos = cursor_pos + len(clipboard_text)
            self.tk_entry.icursor(new_cursor_pos)
            
            return "break"  # Отменяем стандартное поведение
        except Exception as e:
            print(f"Ошибка при вставке: {e}")
            return None
    
    def on_right_click(self, event):
        """Обработка правой кнопки мыши"""
        # Показываем контекстное меню
        try:
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()
        
        return "break"
    
    def show_context_menu(self, event):
        """Показ контекстного меню"""
        try:
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()
    
    def paste_from_menu(self):
        """Вставка из контекстного меню"""
        try:
            clipboard_text = self.root.clipboard_get()
            if clipboard_text:
                # Вставляем на позицию курсора
                cursor_pos = self.tk_entry.index(tk.INSERT)
                current_text = self.code_entry.get()
                
                new_text = current_text[:cursor_pos] + clipboard_text + current_text[cursor_pos:]
                self.code_entry.delete(0, tk.END)
                self.code_entry.insert(0, new_text)
                
                # Перемещаем курсор
                new_cursor_pos = cursor_pos + len(clipboard_text)
                self.tk_entry.icursor(new_cursor_pos)
        except Exception as e:
            print(f"Ошибка вставки из меню: {e}")
    
    def cut_from_menu(self):
        """Вырезание текста"""
        try:
            # Получаем выделенный текст
            selected_text = self.tk_entry.selection_get()
            if selected_text:
                # Копируем в буфер обмена
                self.root.clipboard_clear()
                self.root.clipboard_append(selected_text)
                
                # Удаляем выделенный текст
                start_pos = self.tk_entry.index(tk.SEL_FIRST)
                end_pos = self.tk_entry.index(tk.SEL_LAST)
                
                current_text = self.code_entry.get()
                new_text = current_text[:start_pos] + current_text[end_pos:]
                self.code_entry.delete(0, tk.END)
                self.code_entry.insert(0, new_text)
                
                # Устанавливаем курсор на позицию удаления
                self.tk_entry.icursor(start_pos)
        except:
            pass  # Если ничего не выделено, просто игнорируем
    
    def copy_from_menu(self):
        """Копирование текста"""
        try:
            selected_text = self.tk_entry.selection_get()
            if selected_text:
                self.root.clipboard_clear()
                self.root.clipboard_append(selected_text)
        except:
            pass  # Если ничего не выделено, просто игнорируем
    
    def on_key_press(self, event):
        """Обработка нажатий клавиш для исправления русской раскладки"""
        # Получаем символ клавиши
        char = event.char
        
        # Пропускаем управляющие клавиши
        if len(event.keysym) > 1:
            return
        
        # Если это печатный символ
        if char and char != '':
            # Получаем текущую позицию курсора
            cursor_pos = self.tk_entry.index(tk.INSERT)
            current_text = self.code_entry.get()
            
            # Вставляем символ на позицию курсора
            new_text = current_text[:cursor_pos] + char + current_text[cursor_pos:]
            self.code_entry.delete(0, tk.END)
            self.code_entry.insert(0, new_text)
            
            # Перемещаем курсор после вставленного символа
            self.tk_entry.icursor(cursor_pos + 1)
            
            return "break"  # Отменяем стандартное поведение
        
    def create_gradient_line(self):
        """Создание градиентной линии под заголовком"""
        line_canvas = tk.Canvas(
            self.main_container,
            height=2,
            width=400,
            bg=self.colors["panel"],
            highlightthickness=0
        )
        line_canvas.pack(pady=(10, 30))
        
        # Градиент от прозрачного к синему и обратно
        for i in range(200):
            alpha = abs(i - 100) / 100  # 0 в центре, 1 по краям
            color = self.interpolate_color(self.colors["panel"], self.colors["accent"], alpha)
            line_canvas.create_line(i*2, 0, i*2, 2, fill=color)
    
    def interpolate_color(self, color1, color2, alpha):
        """Интерполяция цвета"""
        r1, g1, b1 = int(color1[1:3], 16), int(color1[3:5], 16), int(color1[5:7], 16)
        r2, g2, b2 = int(color2[1:3], 16), int(color2[3:5], 16), int(color2[5:7], 16)
        
        r = int(r1 + (r2 - r1) * alpha)
        g = int(g1 + (g2 - g1) * alpha)
        b = int(b1 + (b2 - b1) * alpha)
        
        return f"#{r:02x}{g:02x}{b:02x}"
    
    def set_language(self, lang):
        """Установка языка"""
        if self.lang_animating or lang == self.current_lang:
            return
        self.animate_language_change(lang)

    def animate_language_change(self, lang):
        """Плавная анимация смены языка"""
        self.lang_animating = True
        self.eng_btn.configure(state="disabled")
        self.rus_btn.configure(state="disabled")
        fade_target = self.colors["panel"]
        targets = [
            (self.title_label, self.colors["title"]),
            (self.subtitle_label, self.colors["subtitle"]),
            (self.lang_label, self.colors["muted"]),
            (self.activate_btn, self.colors["button_text"]),
            (self.status_label, self.colors["status_ready"]),
            (self.copyright_label, self.colors["muted_dark"]),
        ]
        
        self.animate_color_batch(
            targets,
            fade_target,
            steps=8,
            delay=25,
            on_complete=lambda: self.apply_language(lang, targets, fade_target)
        )

    def apply_language(self, lang, targets, fade_target):
        """Применение языка"""
        self.current_lang = lang
        texts = self.texts[lang]
        
        self.title_label.configure(text=texts["title"])
        self.subtitle_label.configure(text=texts["subtitle"])
        self.lang_label.configure(text=texts["select_lang"])
        self.code_entry.configure(placeholder_text=texts["enter_code"])
        self.activate_btn.configure(text=texts["submit"])
        self.status_label.configure(
            text=texts["status_ready"],
            text_color=self.colors["status_ready"]
        )
        self.copyright_label.configure(text=texts["copyright"])
        
        # Обновление кнопок языка
        self.eng_btn.configure(
            fg_color=self.colors["accent"] if lang == "english" else "#1c2530"
        )
        self.rus_btn.configure(
            fg_color=self.colors["accent"] if lang == "russian" else "#1c2530"
        )
        
        self.animate_color_batch(
            targets,
            None,
            steps=10,
            delay=25,
            on_complete=self.finish_language_animation,
            start_color=fade_target
        )

    def finish_language_animation(self):
        """Завершение анимации"""
        self.lang_animating = False
        self.eng_btn.configure(state="normal")
        self.rus_btn.configure(state="normal")

    def animate_color_batch(self, targets, target_color, steps, delay, on_complete=None, start_color=None):
        """Пакетная анимация цветов"""
        if steps <= 0:
            if on_complete:
                on_complete()
            return
        
        def step(current_step):
            progress = current_step / steps
            for widget, original in targets:
                start_hex = start_color or original
                end_hex = target_color or original
                start = self.hex_to_rgb(start_hex)
                end = self.hex_to_rgb(end_hex)
                color = self.rgb_to_hex(self.interpolate_rgb(start, end, progress))
                if isinstance(widget, ctk.CTkButton):
                    widget.configure(text_color=color)
                else:
                    widget.configure(text_color=color)
            
            if current_step < steps:
                self.root.after(delay, lambda: step(current_step + 1))
            else:
                if on_complete:
                    on_complete()
        
        step(0)

    def hex_to_rgb(self, hex_color):
        """HEX в RGB"""
        return (int(hex_color[1:3], 16), int(hex_color[3:5], 16), int(hex_color[5:7], 16))

    def rgb_to_hex(self, rgb_color):
        """RGB в HEX"""
        return f"#{rgb_color[0]:02x}{rgb_color[1]:02x}{rgb_color[2]:02x}"

    def interpolate_rgb(self, start, end, alpha):
        """Интерполяция RGB"""
        return (
            int(start[0] + (end[0] - start[0]) * alpha),
            int(start[1] + (end[1] - start[1]) * alpha),
            int(start[2] + (end[2] - start[2]) * alpha),
        )
    
    def get_hwid(self):
        """Получение HWID устройства"""
        try:
            def run_cmd(cmd):
                try:
                    return subprocess.check_output(
                        cmd,
                        shell=True,
                        text=True,
                        errors="ignore",
                        timeout=5,
                        stderr=subprocess.DEVNULL,
                    )
                except Exception:
                    return ""

            def parse_value(output):
                if not output:
                    return ""
                lines = [line.strip() for line in output.splitlines() if line.strip()]
                if not lines:
                    return ""
                if len(lines) == 1 and "=" in lines[0]:
                    return lines[0].split("=", 1)[1].strip()
                if len(lines) >= 2:
                    header = lines[0].replace(" ", "").lower()
                    if header in {"serialnumber", "processorid", "uuid"}:
                        lines = lines[1:]
                return lines[0].strip() if lines else ""

            def clean_value(value):
                if not value:
                    return ""
                value = value.strip()
                if not value:
                    return ""
                lower = value.lower()
                invalid_tokens = [
                    "to be filled",
                    "default string",
                    "unknown",
                    "none",
                    "n/a",
                    "invalid",
                    "o.e.m",
                    "oem",
                    "not applicable",
                ]
                if any(token in lower for token in invalid_tokens):
                    return ""
                return value

            def first_value(commands):
                for cmd in commands:
                    if not cmd:
                        continue
                    value = clean_value(parse_value(run_cmd(cmd)))
                    if value:
                        return value
                return ""

            parts = []
            if os.name == "nt":
                has_wmic = shutil.which("wmic") is not None
                bios = first_value([
                    "wmic bios get serialnumber /value" if has_wmic else "",
                    "powershell -NoProfile -Command \"(Get-CimInstance Win32_BIOS).SerialNumber\"",
                ])
                baseboard = first_value([
                    "wmic baseboard get serialnumber /value" if has_wmic else "",
                    "powershell -NoProfile -Command \"(Get-CimInstance Win32_BaseBoard).SerialNumber\"",
                ])
                cpu = first_value([
                    "wmic cpu get processorid /value" if has_wmic else "",
                    "powershell -NoProfile -Command \"(Get-CimInstance Win32_Processor | Select-Object -First 1).ProcessorId\"",
                ])
                disk = first_value([
                    "wmic diskdrive get serialnumber /value" if has_wmic else "",
                    "powershell -NoProfile -Command \"(Get-CimInstance Win32_DiskDrive | Select-Object -First 1).SerialNumber\"",
                ])
                sys_uuid = first_value([
                    "wmic csproduct get uuid /value" if has_wmic else "",
                    "powershell -NoProfile -Command \"(Get-CimInstance Win32_ComputerSystemProduct).UUID\"",
                ])

                if bios:
                    parts.append(f"bios:{bios}")
                if baseboard:
                    parts.append(f"baseboard:{baseboard}")
                if cpu:
                    parts.append(f"cpu:{cpu}")
                if disk:
                    parts.append(f"disk:{disk}")
                if sys_uuid:
                    parts.append(f"uuid:{sys_uuid}")

            if not parts:
                system_info = f"{platform.node()}{platform.processor()}{platform.machine()}"
                parts.append(system_info)

            hwid = hashlib.sha256("|".join(parts).encode()).hexdigest()
            return hwid
        except Exception as e:
            print(f"HWID error: {e}")
            return hashlib.sha256(str(uuid.uuid4()).encode()).hexdigest()
    
    def activate(self):
        """Активация системы"""
        # Защита от повторных нажатий
        if self.activation_in_progress:
            return
            
        code = self.code_entry.get().strip()
        
        print(f"Код для активации: '{code}'")  # Отладочный вывод
        
        if not code or code == self.texts[self.current_lang]["enter_code"]:
            self.status_label.configure(
                text="Please enter activation code" if self.current_lang == "english" else "Введите код активации",
                text_color="#ff5c5c"
            )
            return
        
        # Устанавливаем флаг активации
        self.activation_in_progress = True
        
        # Показ загрузки
        self.activate_btn.configure(
            state="disabled",
            text=self.texts[self.current_lang]["loading"],
            fg_color="#333333"
        )
        self.status_label.configure(text="", text_color="#666666")
        
        # Запуск проверки в отдельном потоке
        thread = threading.Thread(target=self.check_activation, args=(code,))
        thread.daemon = True
        thread.start()
    
    def check_activation(self, code):
        """Проверка активационного кода"""
        try:
            # Проверка интернета
            try:
                response = requests.get("https://google.com", timeout=5)
                if response.status_code != 200:
                    self.show_error("error_internet")
                    return
            except:
                self.show_error("error_internet")
                return
            
            # Получение HWID
            hwid = self.get_hwid()
            
            # Заголовки для Supabase
            headers = {
                "apikey": SUPABASE_KEY,
                "Authorization": f"Bearer {SUPABASE_KEY}",
                "Content-Type": "application/json",
                "Prefer": "return=representation"
            }
            
            print(f"Проверка кода: {code}")
            print(f"HWID: {hwid}")
            
            # Сначала получим ВСЕ записи из таблицы
            print("Запрашиваем все записи из таблицы...")
            response = requests.get(
                f"{SUPABASE_URL}/rest/v1/{TABLE_NAME}",
                headers=headers,
                timeout=15
            )
            
            print(f"Статус ответа: {response.status_code}")
            
            if response.status_code != 200:
                print(f"Ошибка API: {response.text}")
                self.show_error("error_unknown")
                return
            
            all_data = response.json()
            print(f"Всего записей: {len(all_data)}")
            
            # Ищем запись с нашим кодом вручную
            user_data = None
            for record in all_data:
                # Проверяем поле subscription_key
                if record.get("subscription_key") == code:
                    user_data = record
                    print(f"Найдена запись: {record}")
                    break
            
            if not user_data:
                print("Код не найден в базе данных")
                self.show_error("error_incorrect")
                return
            
            print(f"Данные пользователя: {user_data}")
            
            # Получаем данные из записи
            device_count = user_data.get("device_count", 0)
            stored_hwid = user_data.get("hwid") or ""
            first_name = user_data.get("first_name", "User")
            telegram_id = user_data.get("telegram_id")
            
            print(f"Количество устройств: {device_count}")
            print(f"Сохраненный HWID: {stored_hwid}")
            print(f"Текущий HWID: {hwid}")
            print(f"Telegram ID: {telegram_id}")
            
            # Если устройство не зарегистрировано (первая активация)
            if stored_hwid == "":
                # Регистрируем новое устройство
                update_data = {
                    "device_count": device_count + 1,
                }
                
                # Добавляем hwid только если поле существует
                try:
                    update_data["hwid"] = hwid
                    update_data["last_activation"] = datetime.now().isoformat()
                except:
                    pass  # Если поля нет, просто пропускаем
                
                print(f"Обновление с данными: {update_data}")
                
                # Обновляем запись в базе данных по telegram_id
                if telegram_id:
                    update_response = requests.patch(
                        f"{SUPABASE_URL}/rest/v1/{TABLE_NAME}",
                        headers=headers,
                        params={"telegram_id": f"eq.{telegram_id}"},
                        json=update_data,
                        timeout=15
                    )
                    
                    print(f"Ответ на обновление: {update_response.status_code}")
                    print(f"Текст ответа: {update_response.text}")
                    
                    if update_response.status_code in [200, 204]:
                        self.show_welcome(first_name)
                    else:
                        print(f"Ошибка обновления: {update_response.text}")
                        self.show_error("error_unknown")
                else:
                    print("Не найден telegram_id записи для обновления")
                    self.show_error("error_unknown")
                    
            else:
                legacy_match = len(stored_hwid) == 32 and stored_hwid == hwid[:32]
                full_match = stored_hwid == hwid

                if full_match or legacy_match:
                    # Устройство уже авторизовано (или старый HWID)
                    if legacy_match and telegram_id:
                        try:
                            update_data = {
                                "hwid": hwid,
                                "last_activation": datetime.now().isoformat()
                            }
                            requests.patch(
                                f"{SUPABASE_URL}/rest/v1/{TABLE_NAME}",
                                headers=headers,
                                params={"telegram_id": f"eq.{telegram_id}"},
                                json=update_data,
                                timeout=15
                            )
                        except Exception:
                            pass
                    self.show_welcome(first_name)
                else:
                    # HWID не совпадает (устройство используется на другом компьютере)
                    self.show_error("error_hwid")
                
        except requests.exceptions.Timeout:
            print("Ошибка таймаута")
            self.show_error("error_internet")
        except requests.exceptions.RequestException as e:
            print(f"Ошибка запроса: {e}")
            self.show_error("error_internet")
        except Exception as e:
            print(f"Неожиданная ошибка: {e}")
            import traceback
            traceback.print_exc()
            self.show_error("error_unknown")
        finally:
            self.reset_button()
    
    def show_error(self, error_type):
        """Показ ошибки"""
        error_text = self.texts[self.current_lang][error_type]
        self.root.after(0, lambda: self.status_label.configure(
            text=error_text,
            text_color="#ff5c5c"
        ))
    
    def show_welcome(self, first_name):
        """Показ приветствия"""
        welcome_text = self.texts[self.current_lang]["welcome"].format(first_name)
        
        # Анимация успеха
        self.root.after(0, lambda: self.status_label.configure(
            text=welcome_text,
            text_color="#44ff44"
        ))
        
        self.root.after(0, lambda: self.activate_btn.configure(
            fg_color="#16a34a",
            text="✓ ACTIVATED" if self.current_lang == "english" else "✓ АКТИВИРОВАНО"
        ))
        
        # Переход на окно установки через 2 секунды
        self.root.after(2000, lambda: self.open_installation_window(first_name))
    
    def open_installation_window(self, first_name):
        """Открытие окна установки"""
        self._next_install_user = first_name
        self.on_window_close()

    def on_window_close(self):
        """Безопасное закрытие окна активации"""
        if self._closed:
            return
        self._closed = True
        try:
            if hasattr(self, "star_canvas"):
                self.star_canvas.stop_animation()
        except Exception:
            pass
        try:
            self.root.quit()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass
    
    def reset_button(self):
        """Сброс кнопки активации"""
        self.activation_in_progress = False
        self.root.after(0, lambda: self.activate_btn.configure(
            state="normal",
            text=self.texts[self.current_lang]["submit"],
            fg_color=self.colors["accent"]
        ))

class InstallationWindow:
    def __init__(self, username, language="english"):
        self.username = username
        self.language = language
        self.root = ctk.CTk()
        self._closed = False
        
        # Устанавливаем заголовок окна в зависимости от языка
        self.root.title(INSTALLATION_TEXTS[self.language]["window_title"])
        
        # Настройка темы
        ctk.set_appearance_mode("dark")
        
        # Размер окна и центрирование
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        self.width = 800
        self.height = 700
        
        pos_x = (screen_width - self.width) // 2
        pos_y = (screen_height - self.height) // 2
        
        self.root.geometry(f"{self.width}x{self.height}+{pos_x}+{pos_y}")
        self.root.minsize(self.width, self.height)
        self.root.resizable(False, False)
        
        self.colors = {
            "bg": "#05070d",
            "panel": "#0f141b",
            "panel_border": "#1f2732",
            "accent": "#3b82f6",
            "accent_hover": "#2563eb",
            "title": "#f8fafc",
            "subtitle": "#9aa4b2",
            "muted": "#7b8794",
            "muted_dark": "#4b5563",
            "input_bg": "#0b0f14",
            "input_border": "#233042",
            "button_text": "#f8fafc",
            "success": "#10b981",
            "error": "#ef4444",
        }
        
        # Переменные
        self.installation_path = tk.StringVar(value=os.path.join(os.path.expanduser("~"), "JARVIS"))
        self.installation_in_progress = False
        self.current_progress = 0
        
        self.create_ui()
        self.update_ui_texts()
        self.root.protocol("WM_DELETE_WINDOW", self.on_window_close)
    
    def create_ui(self):
        """Создание интерфейса окна установки"""
        # Фрейм для звездного фона
        self.bg_frame = ctk.CTkFrame(self.root, fg_color=self.colors["bg"])
        self.bg_frame.pack(fill="both", expand=True)
        
        # Canvas с звездами
        self.star_canvas = StarfieldCanvas(
            self.bg_frame,
            width=self.width,
            height=self.height,
            bg=self.colors["bg"],
            highlightthickness=0
        )
        self.star_canvas.pack(fill="both", expand=True)
        
        # Карточка-контейнер
        self.card_frame = ctk.CTkFrame(
            self.star_canvas,
            fg_color=self.colors["panel"],
            border_color=self.colors["panel_border"],
            border_width=1,
            corner_radius=24
        )
        self.card_frame.place(relx=0.5, rely=0.5, anchor="center")
        
        # Основной контейнер
        self.main_container = ctk.CTkFrame(
            self.card_frame,
            fg_color="transparent"
        )
        self.main_container.pack(padx=40, pady=40)
        
        # Анимация появления заголовка
        self.title_label = ctk.CTkLabel(
            self.main_container,
            text="",  # Будет установлено в update_ui_texts()
            font=("Montserrat", 32, "bold"),
            text_color=self.colors["title"]
        )
        self.title_label.pack(pady=(0, 10))
        
        # Приветствие пользователя
        self.welcome_label = ctk.CTkLabel(
            self.main_container,
            text="",  # Будет установлено в update_ui_texts()
            font=("Montserrat", 16),
            text_color=self.colors["subtitle"]
        )
        self.welcome_label.pack(pady=(0, 30))
        
        # Контейнер для выбора пути
        self.path_frame = ctk.CTkFrame(
            self.main_container,
            fg_color="transparent"
        )
        self.path_frame.pack(pady=(0, 20), fill="x")
        
        # Метка для выбора пути
        self.path_label = ctk.CTkLabel(
            self.path_frame,
            text="",  # Будет установлено в update_ui_texts()
            font=("Montserrat", 12, "bold"),
            text_color=self.colors["muted"]
        )
        self.path_label.pack(anchor="w", pady=(0, 5))
        
        # Фрейм для поля ввода и кнопки
        self.path_input_frame = ctk.CTkFrame(
            self.path_frame,
            fg_color="transparent"
        )
        self.path_input_frame.pack(fill="x")
        
        # Поле ввода пути
        self.path_entry = ctk.CTkEntry(
            self.path_input_frame,
            textvariable=self.installation_path,
            height=45,
            font=("Montserrat", 12),
            text_color=self.colors["title"],
            fg_color=self.colors["input_bg"],
            border_color=self.colors["input_border"],
            corner_radius=10
        )
        self.path_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))
        
        # Кнопка выбора папки
        self.browse_btn = ctk.CTkButton(
            self.path_input_frame,
            text="",  # Будет установлено в update_ui_texts()
            width=100,
            height=45,
            font=("Montserrat", 12, "bold"),
            fg_color=self.colors["accent"],
            hover_color=self.colors["accent_hover"],
            text_color=self.colors["button_text"],
            command=self.browse_folder
        )
        self.browse_btn.pack(side="right")
        
        # Кнопка установки
        self.install_btn = ctk.CTkButton(
            self.main_container,
            text="",  # Будет установлено в update_ui_texts()
            height=50,
            font=("Montserrat", 14, "bold"),
            fg_color=self.colors["accent"],
            hover_color=self.colors["accent_hover"],
            text_color=self.colors["button_text"],
            corner_radius=10,
            command=self.start_installation
        )
        self.install_btn.pack(pady=(20, 0), fill="x")
        
        # Контейнер для прогресса (изначально скрыт)
        self.progress_container = ctk.CTkFrame(
            self.main_container,
            fg_color="transparent"
        )
        
        # Разделительная линия
        self.separator = ctk.CTkFrame(
            self.progress_container,
            height=1,
            fg_color=self.colors["panel_border"]
        )
        self.separator.pack(fill="x", pady=(30, 20))
        
        # Заголовок прогресса
        self.progress_title = ctk.CTkLabel(
            self.progress_container,
            text="",  # Будет установлено в update_ui_texts()
            font=("Montserrat", 14, "bold"),
            text_color=self.colors["title"]
        )
        self.progress_title.pack(pady=(0, 15))
        
        # Фрейм для прогресс-бара
        self.progress_bar_frame = ctk.CTkFrame(
            self.progress_container,
            fg_color="transparent"
        )
        self.progress_bar_frame.pack(fill="x", pady=(0, 10))
        
        # Прогресс-бар
        self.progress_bar = ctk.CTkProgressBar(
            self.progress_bar_frame,
            height=20,
            width=400,
            progress_color=self.colors["accent"],
            border_color=self.colors["panel_border"],
            fg_color=self.colors["input_bg"]
        )
        self.progress_bar.pack()
        self.progress_bar.set(0)
        
        # Метка прогресса
        self.progress_label = ctk.CTkLabel(
            self.progress_bar_frame,
            text="0%",
            font=("Montserrat", 12, "bold"),
            text_color=self.colors["muted"]
        )
        self.progress_label.pack(pady=(5, 0))
        
        # Текстовый лог
        self.log_text = ctk.CTkTextbox(
            self.progress_container,
            height=150,
            font=("Consolas", 10),
            text_color=self.colors["subtitle"],
            fg_color=self.colors["input_bg"],
            border_color=self.colors["input_border"],
            border_width=1
        )
        self.log_text.pack(fill="x", pady=(10, 0))
        self.log_text.configure(state="disabled")
        
        # Кнопка запуска (изначально скрыта)
        self.launch_btn = ctk.CTkButton(
            self.main_container,
            text="",  # Будет установлено в update_ui_texts()
            height=50,
            font=("Montserrat", 14, "bold"),
            fg_color=self.colors["success"],
            hover_color="#059669",
            text_color=self.colors["button_text"],
            corner_radius=10,
            command=self.launch_jarvis
        )
        
        # Кнопка открытия папки
        self.open_folder_btn = ctk.CTkButton(
            self.main_container,
            text="",  # Будет установлено в update_ui_texts()
            height=45,
            font=("Montserrat", 12, "bold"),
            fg_color=self.colors["panel_border"],
            hover_color=self.colors["muted_dark"],
            text_color=self.colors["button_text"],
            corner_radius=10,
            command=self.open_installation_folder
        )
    
    def update_ui_texts(self):
        """Обновление всех текстов в UI в соответствии с выбранным языком"""
        texts = INSTALLATION_TEXTS[self.language]
        
        # Обновляем заголовок окна
        self.root.title(texts["window_title"])
        
        # Обновляем все текстовые элементы
        self.title_label.configure(text=texts["title"])
        self.welcome_label.configure(text=texts["welcome"].format(self.username))
        self.path_label.configure(text=texts["path_label"])
        self.browse_btn.configure(text=texts["browse"])
        self.install_btn.configure(text=texts["install"])
        self.progress_title.configure(text=texts["progress_title"])
        self.launch_btn.configure(text=texts["launch"])
        self.open_folder_btn.configure(text=texts["open_folder"])
    
    def browse_folder(self):
        """Выбор папки для установки"""
        texts = INSTALLATION_TEXTS[self.language]
        folder = filedialog.askdirectory(
            title=texts["folder_dialog_title"],
            initialdir=os.path.expanduser("~")
        )
        if folder:
            self.installation_path.set(os.path.join(folder, "JARVIS"))
    
    def start_installation(self):
        """Начало процесса установки"""
        if self.installation_in_progress:
            return
        
        # Проверка пути
        install_path = self.installation_path.get().strip()
        if not install_path:
            texts = INSTALLATION_TEXTS[self.language]
            messagebox.showerror("Error", texts["error_no_path"])
            return
        
        # Отображаем прогресс-контейнер
        self.progress_container.pack(pady=(30, 0), fill="x")
        self.install_btn.configure(state="disabled", fg_color=self.colors["muted_dark"])
        self.browse_btn.configure(state="disabled")
        self.path_entry.configure(state="disabled")
        
        # Запуск установки в отдельном потоке
        self.installation_in_progress = True
        thread = threading.Thread(target=self.installation_process, args=(install_path,))
        thread.daemon = True
        thread.start()
    
    def installation_process(self, install_path):
        """Процесс установки"""
        try:
            texts = INSTALLATION_TEXTS[self.language]
            
            # Создание папки JARVIS
            self.update_progress(10, texts["progress_creating"])
            jarvis_path = Path(install_path)
            jarvis_path.mkdir(parents=True, exist_ok=True)
            
            # Скачивание EXE файла
            self.update_progress(20, texts["progress_downloading_exe"])
            exe_path = jarvis_path / "JarvisAssistant.V6.PUBLIC.exe"
            self.download_file(EXE_DOWNLOAD_URL, exe_path, "JARVIS Executable")
            
            # Скачивание файлов из репозитория
            self.update_progress(40, texts["progress_downloading_files"])
            
            # Получаем список файлов из GitHub API
            api_url = "https://api.github.com/repos/alek10er/JRV-ASSISTENT-PUBLIC/contents"
            headers = {"Accept": "application/vnd.github.v3+json"}
            
            try:
                response = requests.get(api_url, headers=headers, timeout=10)
                if response.status_code == 200:
                    files = response.json()
                    total_files = len([f for f in files if f["type"] == "file"])
                    downloaded_files = 0
                    
                    for file_info in files:
                        if file_info["type"] == "file":
                            file_url = file_info["download_url"]
                            file_name = file_info["name"]
                            file_path = jarvis_path / file_name
                            
                            # Пропускаем если это EXE файл (мы уже скачали его отдельно)
                            if file_name.lower().endswith(".exe"):
                                continue
                            
                            self.update_log(texts["log_downloading"].format(file_name))
                            self.download_file(file_url, file_path, file_name)
                            
                            downloaded_files += 1
                            progress = 40 + (downloaded_files / total_files * 40)
                            self.update_progress(min(progress, 80), 
                                               texts["log_downloaded"].format(downloaded_files, total_files))
                else:
                    self.update_log(f"Warning: Could not fetch file list from GitHub (Status: {response.status_code})")
            except Exception as e:
                self.update_log(f"Warning: Could not fetch repository files: {str(e)}")
            
            # Скачивание конфигурационных файлов
            self.update_progress(85, texts["progress_configs"])
            
            # Пытаемся скачать папку configs
            configs_path = jarvis_path / "configs"
            configs_path.mkdir(exist_ok=True)
            
            try:
                configs_api_url = "https://api.github.com/repos/alek10er/JRV-ASSISTENT-PUBLIC/contents/configs"
                config_response = requests.get(configs_api_url, headers=headers, timeout=10)
                if config_response.status_code == 200:
                    config_files = config_response.json()
                    for config_file in config_files:
                        if config_file["type"] == "file":
                            config_file_url = config_file["download_url"]
                            config_file_name = config_file["name"]
                            config_file_path = configs_path / config_file_name
                            
                            self.update_log(texts["log_downloading_config"].format(config_file_name))
                            self.download_file(config_file_url, config_file_path, config_file_name)
            except:
                pass  # Игнорируем ошибки с конфигами
            
            # Скачивание модели VOSK
            self.update_progress(90, texts["progress_model"])
            
            try:
                model_api_url = "https://api.github.com/repos/alek10er/JRV-ASSISTENT-PUBLIC/contents/vosk-model-small-ru-0.22"
                model_response = requests.get(model_api_url, headers=headers, timeout=10)
                if model_response.status_code == 200:
                    model_files = model_response.json()
                    model_path = jarvis_path / "vosk-model-small-ru-0.22"
                    model_path.mkdir(exist_ok=True)
                    
                    for model_file in model_files:
                        if model_file["type"] == "file":
                            model_file_url = model_file["download_url"]
                            model_file_name = model_file["name"]
                            model_file_path = model_path / model_file_name
                            
                            self.update_log(texts["log_downloading_model"].format(model_file_name))
                            self.download_file(model_file_url, model_file_path, model_file_name)
            except:
                pass  # Игнорируем ошибки с моделью
            
            # Завершение установки
            self.update_progress(95, texts["progress_finalizing"])
            
            # Создание README файла на правильном языке
            readme_path = jarvis_path / "README.txt"
            with open(readme_path, "w", encoding="utf-8") as f:
                f.write(f"{texts['readme_title']}\n")
                f.write(f"{'=' * len(texts['readme_title'])}\n")
                f.write(f"{texts['readme_installed_for'].format(self.username)}\n")
                f.write(f"{texts['readme_date'].format(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}\n")
                f.write(f"{texts['readme_location'].format(jarvis_path)}\n")
                f.write(f"\n{texts['readme_run']}\n")
            
            self.update_progress(100, texts["progress_completed"])
            
            # Показываем кнопки запуска и открытия папки
            self.root.after(0, self.show_completion_buttons)
            
        except Exception as e:
            texts = INSTALLATION_TEXTS[self.language]
            self.update_progress(0, texts["error_install_failed"].format(str(e)))
            self.update_log(f"Error: {str(e)}")
            self.root.after(0, lambda: messagebox.showerror("Installation Error", 
                                                          texts["error_install_failed"].format(str(e))))
            self.root.after(0, self.reset_installation_ui)
        finally:
            self.installation_in_progress = False
    
    def download_file(self, url, file_path, file_name):
        """Скачивание файла с отображением прогресса"""
        try:
            headers = {"User-Agent": "Mozilla/5.0"}
            response = requests.get(url, headers=headers, stream=True, timeout=30)
            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0
            self._last_log_time = 0.0
            self._last_log_percent = -1
            
            with open(file_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        
                        if total_size > 0:
                            percent = (downloaded / total_size) * 100
                            now = time.time()
                            if (
                                percent - self._last_log_percent >= self._log_percent_step
                                or now - self._last_log_time >= self._log_interval
                                or percent >= 100
                            ):
                                self._last_log_percent = percent
                                self._last_log_time = now
                                self.update_log(
                                    f"  {file_name}: {downloaded/1024/1024:.1f}MB / {total_size/1024/1024:.1f}MB ({percent:.1f}%)"
                                )
            
            return True
        except Exception as e:
            self.update_log(f"  Failed to download {file_name}: {str(e)}")
            return False
    
    def update_progress(self, value, message):
        """Обновление прогресса и сообщения"""
        self.root.after(0, lambda: self.progress_bar.set(value / 100))
        self.root.after(0, lambda: self.progress_label.configure(text=f"{int(value)}%"))
        self.update_log(message)
    
    def update_log(self, message):
        """Добавление сообщения в лог"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_message = f"[{timestamp}] {message}\n"
        
        self.root.after(0, lambda: self.log_text.configure(state="normal"))
        self.root.after(0, lambda: self.log_text.insert("end", log_message))
        self.root.after(0, lambda: self.log_text.see("end"))
        self.root.after(0, lambda: self.log_text.configure(state="disabled"))
    
    def show_completion_buttons(self):
        """Показ кнопок после завершения установки"""
        self.install_btn.pack_forget()
        self.launch_btn.pack(pady=(20, 10), fill="x")
        self.open_folder_btn.pack(pady=(0, 20), fill="x")
    
    def reset_installation_ui(self):
        """Сброс UI после ошибки"""
        self.install_btn.configure(state="normal", fg_color=self.colors["accent"])
        self.browse_btn.configure(state="normal")
        self.path_entry.configure(state="normal")
    
    def launch_jarvis(self):
        """Запуск JARVIS"""
        install_path = self.installation_path.get().strip()
        exe_path = Path(install_path) / "JarvisAssistant.V6.PUBLIC.exe"
        
        texts = INSTALLATION_TEXTS[self.language]
        
        if exe_path.exists():
            try:
                subprocess.Popen([str(exe_path)], cwd=install_path)
                self.update_log(texts["log_launched"])
                self.root.after(3000, self.on_window_close)
            except Exception as e:
                messagebox.showerror("Launch Error", f"Failed to launch JARVIS: {str(e)}")
        else:
            messagebox.showerror("Error", texts["error_launch"])
    
    def open_installation_folder(self):
        """Открытие папки с установкой"""
        install_path = self.installation_path.get().strip()
        texts = INSTALLATION_TEXTS[self.language]
        
        if os.path.exists(install_path):
            try:
                if sys.platform == "win32":
                    os.startfile(install_path)
                elif sys.platform == "darwin":
                    subprocess.Popen(["open", install_path])
                else:
                    subprocess.Popen(["xdg-open", install_path])
                self.update_log(texts["log_folder_opened"])
            except Exception as e:
                messagebox.showerror("Error", f"Failed to open folder: {str(e)}")
        else:
            messagebox.showerror("Error", texts["error_folder"])
    
    def run(self):
        """Запуск окна установки"""
        self.root.mainloop()

    def on_window_close(self):
        """Безопасное закрытие окна установки"""
        if self._closed:
            return
        self._closed = True
        try:
            if hasattr(self, "star_canvas"):
                self.star_canvas.stop_animation()
        except Exception:
            pass
        try:
            self.root.quit()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass

def main():
    """Точка входа в программу"""
    try:
        app = ModernActivationApp()
    except Exception as e:
        print(f"Ошибка запуска: {e}")
        import traceback
        traceback.print_exc()
        messagebox.showerror("Error", f"Failed to start application: {e}")

if __name__ == "__main__":
    main()
