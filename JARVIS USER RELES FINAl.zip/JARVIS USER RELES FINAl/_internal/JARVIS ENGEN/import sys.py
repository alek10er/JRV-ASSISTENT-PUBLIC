﻿import webview
import threading
import time
import socket
import os
import sys
import subprocess
import runpy
from datetime import datetime
from screeninfo import get_monitors

APP_MAIN_EXE = "JARVIS_MAIN.exe"
MAIN_MODE_ARG = "--run-main"
RUNTIME_DIR = os.path.join(os.getenv("LOCALAPPDATA") or os.getcwd(), "JARVIS_AI")
RUNTIME_LOG = os.path.join(RUNTIME_DIR, "runtime.log")


def _log(msg):
    try:
        os.makedirs(RUNTIME_DIR, exist_ok=True)
        with open(RUNTIME_LOG, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().isoformat(sep=' ', timespec='seconds')}] [loader] {msg}\n")
    except Exception:
        pass


def _get_main_script_path():
    candidates = []
    if getattr(sys, "frozen", False):
        meipass = getattr(sys, "_MEIPASS", "")
        if meipass:
            candidates.append(os.path.join(meipass, "JARVIS ENGEN", "import webview.py"))
        candidates.append(os.path.join(os.path.dirname(sys.executable), "JARVIS ENGEN", "import webview.py"))
    else:
        engine_dir = resolve_engine_dir()
        candidates.append(os.path.join(engine_dir, "import webview.py"))

    for path in candidates:
        if path and os.path.exists(path):
            return path
    return None

def _resolve_main_target():
    if getattr(sys, "frozen", False):
        base_dir = os.path.dirname(sys.executable)
        exe_target = os.path.join(base_dir, APP_MAIN_EXE)
        if os.path.exists(exe_target):
            return "exe", exe_target
        script_target = _get_main_script_path()
        if script_target:
            return "self", script_target
    script_target = _get_main_script_path()
    return "script", script_target or ""


def _run_main_inline():
    script_path = _get_main_script_path()
    if not script_path:
        _log("main inline script path not found")
        return 2
    script_dir = os.path.dirname(script_path)
    if script_dir and script_dir not in sys.path:
        sys.path.insert(0, script_dir)
    _log(f"run main inline: {script_path}")
    runpy.run_path(script_path, run_name="__main__")
    return 0

def resolve_engine_dir():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        base_dir,
        os.path.join(base_dir, "JARVIS ENGEN"),
        os.path.join(os.path.dirname(base_dir), "JARVIS ENGEN"),
    ]
    for candidate in candidates:
        if os.path.exists(os.path.join(candidate, "import webview.py")):
            return candidate
    return base_dir

def get_center_position(width, height):
    """Р’С‹С‡РёСЃР»РµРЅРёРµ РєРѕРѕСЂРґРёРЅР°С‚ РґР»СЏ С†РµРЅС‚СЂРёСЂРѕРІР°РЅРёСЏ РѕРєРЅР°"""
    try:
        # РџРѕР»СѓС‡Р°РµРј РёРЅС„РѕСЂРјР°С†РёСЋ Рѕ РјРѕРЅРёС‚РѕСЂРµ
        monitor = get_monitors()[0]
        x = (monitor.width - width) // 2
        y = (monitor.height - height) // 2
        return x, y
    except:
        # Р•СЃР»Рё screeninfo РЅРµ СѓСЃС‚Р°РЅРѕРІР»РµРЅ, РІРѕР·РІСЂР°С‰Р°РµРј None
        return None, None

def check_internet():
    """РџСЂРѕРІРµСЂРєР° РёРЅС‚РµСЂРЅРµС‚Р° - РІРѕР·РІСЂР°С‰Р°РµС‚ True/False Рё СЃРѕРѕР±С‰РµРЅРёРµ"""
    dns_ok = False
    for host in (("1.1.1.1", 53), ("8.8.8.8", 53)):
        try:
            sock = socket.create_connection(host, timeout=3)
            sock.close()
            dns_ok = True
            break
        except:
            continue

    try:
        import urllib.request

        checks = [
            ("http://www.msftconnecttest.com/connecttest.txt", b"Microsoft Connect Test", 200),
            ("http://clients3.google.com/generate_204", b"", 204),
        ]

        for url, marker, expected_status in checks:
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=4) as resp:
                    status = getattr(resp, "status", resp.getcode())
                    data = resp.read(64)
                if status == expected_status and (not marker or marker in data):
                    return True, "Интернет: OK"
            except:
                continue
    except:
        pass

    if dns_ok:
        return False, "Интернет: нет доступа"
    return False, "Интернет: нет соединения"

def check_resources():
    """РџСЂРѕРІРµСЂРєР° СЂРµСЃСѓСЂСЃРѕРІ"""
    try:
        import psutil
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('.')
        
        mem_gb = memory.total / (1024**3)
        disk_gb = disk.free / (1024**3)
        
        if mem_gb >= 2 and disk_gb >= 2:
            return True, f"Ресурсы: OK ({mem_gb:.1f}GB RAM, {disk_gb:.1f}GB free)"
        else:
            msg = f"Ресурсы: мало (RAM: {mem_gb:.1f}GB, Disk: {disk_gb:.1f}GB)"
            return False, msg
    except:
        return True, "Ресурсы: проверка пропущена"

def preload_components():
    """РџРѕРґРіСЂСѓР·РєР° Рё РїСЂРѕРІРµСЂРєР° РєРѕРјРїРѕРЅРµРЅС‚РѕРІ РёРЅС‚РµСЂС„РµР№СЃР°"""
    target_mode, target = _resolve_main_target()
    if target_mode == "exe":
        if not os.path.exists(target):
            return False, "Основной EXE не найден"
        return True, ""
    if target_mode == "self":
        if not target or not os.path.exists(target):
            return False, "Файл интерфейса не найден"
        return True, ""

    engine_dir = resolve_engine_dir()

    if not os.path.exists(target):
        return False, "Файл интерфейса не найден"

    # РџСЂРѕРІРµСЂСЏРµРј РЅР°Р»РёС‡РёРµ HTML-РёРЅС‚РµСЂС„РµР№СЃР°
    html_files = [
        "\u041c\u043e\u0437\u0433\u0438 \u0431\u0435\u0437 \u0441\u043f\u0438\u043a.html",
        "\u0414\u0438\u0437\u0430\u0439\u043d + \u043c\u043e\u0437\u0433\u0438.html",
        "jarvis.html",
        "index.html",
    ]
    html_path = None
    for name in html_files:
        candidate = os.path.join(engine_dir, name)
        if os.path.exists(candidate):
            html_path = candidate
            break

    if not html_path:
        try:
            candidates = [
                f for f in os.listdir(engine_dir)
                if f.lower().endswith(".html") and f.lower() != "jarvis_temp.html"
            ]
        except Exception:
            candidates = []
        if candidates:
            html_path = os.path.join(engine_dir, candidates[0])

    if not html_path or not os.path.exists(html_path):
        return False, "HTML интерфейс не найден"

    # РџСЂРѕР±СѓРµРј РёРјРїРѕСЂС‚РёСЂРѕРІР°С‚СЊ Р·Р°РІРёСЃРёРјРѕСЃС‚Рё, С‡С‚РѕР±С‹ СѓР±РµРґРёС‚СЊСЃСЏ С‡С‚Рѕ Р·Р°РїСѓСЃРє РЅРµ СѓРїР°РґРµС‚
    try:
        import requests  # noqa: F401
    except Exception:
        return False, "Модуль requests не найден"

    # Р‘С‹СЃС‚СЂРѕ С‡РёС‚Р°РµРј HTML РґР»СЏ РїСЂРѕРіСЂРµРІР° РґРёСЃРєР°/РєСЌС€Р°
    try:
        with open(html_path, "rb") as f:
            f.read(64 * 1024)
    except Exception:
        return False, "Не удалось прочитать HTML"

    return True, ""

def preload_main_startup(timeout=25):
    """РџСЂРµРґР·Р°РіСЂСѓР·РєР° РґР°РЅРЅС‹С… РѕСЃРЅРѕРІРЅРѕРіРѕ РїСЂРёР»РѕР¶РµРЅРёСЏ (HWID/РїРѕРґРїРёСЃРєР°/РєСЌС€)."""
    target_mode, target = _resolve_main_target()
    if not os.path.exists(target):
        return False, "Файл интерфейса не найден"

    try:
        cmd = [sys.executable, target, "--preload-startup"]
        cwd = os.path.dirname(target)
        if target_mode == "exe":
            cmd = [target, "--preload-startup"]
            cwd = os.path.dirname(target)
        elif target_mode == "self":
            cmd = [sys.executable, MAIN_MODE_ARG, "--preload-startup"]
            cwd = os.path.dirname(sys.executable)
        _log(f"preload start: mode={target_mode} cmd={cmd}")
        proc = subprocess.run(
            cmd,
            cwd=cwd,
            timeout=timeout,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        _log(f"preload returncode={proc.returncode}")
        if proc.returncode == 0:
            return True, ""
        return False, f"Код завершения предзагрузки: {proc.returncode}"
    except subprocess.TimeoutExpired:
        return False, "Таймаут предзагрузки основного приложения"
    except Exception as e:
        return False, str(e)

def launch_main_app(retries=1):
    """Р—Р°РїСѓСЃРє РѕСЃРЅРѕРІРЅРѕРіРѕ РёРЅС‚РµСЂС„РµР№СЃР°"""
    target_mode, target = _resolve_main_target()
    if not os.path.exists(target):
        return False, "Файл интерфейса не найден"

    last_err = ""
    for _ in range(retries + 1):
        try:
            cmd = [sys.executable, target]
            cwd = os.path.dirname(target)
            if target_mode == "exe":
                cmd = [target]
                cwd = os.path.dirname(target)
            elif target_mode == "self":
                cmd = [sys.executable, MAIN_MODE_ARG]
                cwd = os.path.dirname(sys.executable)
            _log(f"launch main: mode={target_mode} cmd={cmd}")
            proc = subprocess.Popen(cmd, cwd=cwd)
        except Exception as e:
            _log(f"launch main exception: {e}")
            last_err = str(e)
            continue

        time.sleep(1.2)
        if proc.poll() is None:
            _log("launch main: process is running")
            return True, ""
        last_err = f"Процесс завершился с кодом {proc.returncode}"
        _log(last_err)

    return False, last_err or "Не удалось запустить интерфейс"

def simulate_loading(window):
    """РџСЂРѕС†РµСЃСЃ Р·Р°РіСЂСѓР·РєРё СЃ РїСЂРѕРІРµСЂРєРѕР№ РёРЅС‚РµСЂРЅРµС‚Р°"""
    try:
        # 1. РџСЂРѕРІРµСЂРєР° РёРЅС‚РµСЂРЅРµС‚Р° (РћР‘РЇР—РђРўР•Р›Р¬РќР«Р™ Р­РўРђРџ)
        window.evaluate_js("updateStatus('Проверка интернет-соединения...', 10)")
        time.sleep(1.0)  # Р”Р°РµРј РІСЂРµРјСЏ РЅР° РїСЂРѕРІРµСЂРєСѓ
        
        internet_ok, net_msg = check_internet()
        
        if not internet_ok:
            # Р•СЃР»Рё РЅРµС‚ РёРЅС‚РµСЂРЅРµС‚Р° - РѕСЃС‚Р°РЅР°РІР»РёРІР°РµРј Р·Р°РіСЂСѓР·РєСѓ
            window.evaluate_js(f"updateStatus('{net_msg}', 20)")
            window.evaluate_js("updateStatus('ОШИБКА: требуется интернет!', 20)")
            window.evaluate_js("updateStatus('Подключитесь к сети и перезапустите', 20)")
            time.sleep(3.0)  # Р”Р°РµРј РІСЂРµРјСЏ РїСЂРѕС‡РёС‚Р°С‚СЊ СЃРѕРѕР±С‰РµРЅРёРµ
            window.destroy()
            return  # РџСЂРµСЂС‹РІР°РµРј Р·Р°РіСЂСѓР·РєСѓ
        
        window.evaluate_js(f"updateStatus('{net_msg}', 20)")
        time.sleep(0.5)
        
        # 2. РџСЂРѕРІРµСЂРєР° СЂРµСЃСѓСЂСЃРѕРІ (С‚РѕР»СЊРєРѕ РµСЃР»Рё РµСЃС‚СЊ РёРЅС‚РµСЂРЅРµС‚)
        window.evaluate_js("updateStatus('Проверка системных ресурсов...', 30)")
        time.sleep(0.8)
        resources_ok, res_msg = check_resources()
        window.evaluate_js(f"updateStatus('{res_msg}', 40)")
        time.sleep(0.3)
        
        # 3. Р—Р°РіСЂСѓР·РєР° СЏРґСЂР° РР (С‚СЂРµР±СѓРµС‚ РёРЅС‚РµСЂРЅРµС‚Р°)
        window.evaluate_js("updateStatus('Загрузка ядра ИИ...', 50)")
        time.sleep(1.5)
        window.evaluate_js("updateStatus('Ядро ИИ загружено', 60)")
        time.sleep(0.3)
        
        # 4. РРЅРёС†РёР°Р»РёР·Р°С†РёСЏ РјРѕРґСѓР»РµР№ (С‚СЂРµР±СѓРµС‚ РёРЅС‚РµСЂРЅРµС‚Р°)
        window.evaluate_js("updateStatus('Инициализация модулей...', 70)")
        time.sleep(1.2)
        window.evaluate_js("updateStatus('Модули готовы', 80)")
        time.sleep(0.3)
        
        # 5. РћРїС‚РёРјРёР·Р°С†РёСЏ СЃРёСЃС‚РµРјС‹
        window.evaluate_js("updateStatus('Оптимизация системы...', 85)")
        time.sleep(0.9)
        window.evaluate_js("updateStatus('Оптимизация завершена', 90)")
        time.sleep(0.3)
        
        # 6. Р¤РёРЅР°Р»СЊРЅР°СЏ РїСЂРѕРІРµСЂРєР°
        window.evaluate_js("updateStatus('Финальная проверка...', 92)")
        time.sleep(0.6)

        # 7. РџРѕРґРіСЂСѓР·РєР° РєРѕРјРїРѕРЅРµРЅС‚РѕРІ
        window.evaluate_js("updateStatus('Подготовка интерфейса...', 95)")
        preload_ok, preload_msg = preload_components()
        if not preload_ok:
            window.evaluate_js(f"updateStatus('ОШИБКА: {preload_msg}', 100)")
            time.sleep(3.0)
            window.destroy()
            return
        time.sleep(0.4)

        window.evaluate_js("updateStatus('Предзагрузка основной программы...', 97)")
        warm_ok, warm_msg = preload_main_startup(timeout=25)
        if not warm_ok:
            window.evaluate_js(f"updateStatus('Прогрев пропущен: {warm_msg}', 97)")
            time.sleep(0.6)

        window.evaluate_js("updateStatus('Запуск интерфейса...', 98)")
        started, err = launch_main_app(retries=1)
        if not started:
            window.evaluate_js("updateStatus('ОШИБКА: Не удалось запустить интерфейс', 100)")
            time.sleep(2.5)
        else:
            window.evaluate_js("updateStatus('Интерфейс запущен', 100)")
            time.sleep(0.6)
        
    except Exception as e:
        # РћР±СЂР°Р±РѕС‚РєР° РѕС€РёР±РѕРє
        error_msg = str(e)[:50]
        window.evaluate_js(f"updateStatus('Ошибка загрузки: {error_msg}', 100)")
        time.sleep(3.0)
    
    # Р—Р°РєСЂС‹РІР°РµРј РѕРєРЅРѕ
    window.destroy()

html = """<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>JARVIS AI</title>
    <style>
        :root {
            --bg0:#07090d;
            --bg1:#0b0f16;
            --bg2:#0f1622;
            --txt:#e8edf7;
            --muted:#8b93a7;
            --muted2:#6f768a;
            --accent:#ff2b2b;
            --accent2:#b80000;
            --ok:#19c37d;
            --warn:#f5a524;

            --glass: rgba(255,255,255,.04);
            --glass2: rgba(255,255,255,.06);
            --shadow: 0 18px 50px rgba(0,0,0,.6);
            --shadow2: 0 10px 26px rgba(0,0,0,.45);
            --radius: 16px;
            --radius2: 22px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            height: 100%;
        }

        body {
            background:
                radial-gradient(1000px 500px at 70% 20%, rgba(255,43,43,.10), transparent 60%),
                radial-gradient(900px 520px at 20% 90%, rgba(255,43,43,.06), transparent 62%),
                linear-gradient(180deg, var(--bg0), var(--bg1));
            width: 100vw;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: "Segoe UI", system-ui, -apple-system, Arial, sans-serif;
            color: var(--txt);
            overflow: hidden;
        }

        .container {
            width: min(880px, 94vw);
            height: min(430px, 86vh);
            padding: 22px;
            display: grid;
            grid-template-columns: 1.15fr 0.85fr;
            gap: 18px;
            border-radius: var(--radius2);
            background: rgba(0,0,0,.32);
            border: 1px solid rgba(255,255,255,.06);
            box-shadow: var(--shadow);
            position: relative;
            overflow: hidden;
        }

        .container::before {
            content: "";
            position: absolute;
            inset: 0;
            border-radius: inherit;
            background:
                radial-gradient(600px 160px at 20% 0%, rgba(255,43,43,.08), transparent 60%),
                radial-gradient(500px 200px at 90% 100%, rgba(255,43,43,.06), transparent 60%);
            pointer-events: none;
        }

        .left-panel,
        .right-panel {
            position: relative;
            z-index: 1;
        }

        .left-panel {
            display: flex;
            flex-direction: column;
            gap: 12px;
            padding: 16px;
            border-radius: var(--radius);
            background: var(--glass);
            box-shadow: var(--shadow2);
        }

        .brand {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap: 10px;
            user-select: none;
        }

        .app-icon {
            width: 64px;
            height: 64px;
            background: linear-gradient(135deg, var(--accent) 0%, var(--accent2) 100%);
            border-radius: 18px;
            display: grid;
            place-items: center;
            color: #ffffff;
            font-size: 26px;
            font-weight: 900;
            box-shadow: 0 10px 24px rgba(255,43,43,.28);
            animation: pulse 3.2s ease-in-out infinite;
            transition: all 0.5s ease;
        }

        .app-name {
            font-size: 28px;
            font-weight: 900;
            letter-spacing: .6px;
            color: var(--txt);
            transition: all 0.5s ease;
        }

        .app-tag {
            font-size: 11px;
            letter-spacing: .8px;
            text-transform: uppercase;
            color: var(--accent);
            font-weight: 900;
        }

        .app-subtitle {
            font-size: 12px;
            color: var(--muted);
            font-weight: 500;
            line-height: 1.5;
        }

        .meta {
            margin-top: auto;
            display: flex;
            flex-direction: column;
            gap: 8px;
            color: var(--muted2);
            font-size: 11px;
        }

        .meta-line {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .meta-dot {
            width: 8px;
            height: 8px;
            border-radius: 999px;
            background: var(--accent);
            box-shadow: 0 0 12px rgba(255,43,43,.5);
        }

        .right-panel {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 14px;
            padding: 8px 10px;
        }

        .progress-container {
            position: relative;
            width: 132px;
            height: 132px;
        }

        .progress-ring {
            width: 100%;
            height: 100%;
            transform: rotate(-90deg);
        }

        .progress-ring-bg {
            fill: none;
            stroke: rgba(255, 255, 255, 0.08);
            stroke-width: 8;
        }

        .progress-ring-circle {
            fill: none;
            stroke: var(--accent);
            stroke-width: 8;
            stroke-linecap: round;
            stroke-dasharray: 440;
            stroke-dashoffset: 440;
            transition: stroke-dashoffset 0.3s ease, stroke 0.5s ease;
        }

        .percentage {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 24px;
            font-weight: 800;
            letter-spacing: .4px;
            color: var(--txt);
            transition: color 0.5s ease;
        }

        .status-container {
            width: 100%;
            max-width: 300px;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .status-box {
            background: var(--glass2);
            border-radius: 16px;
            padding: 16px;
            text-align: center;
            min-height: 84px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            box-shadow: var(--shadow2);
            border: 1px solid rgba(255,255,255,.06);
            transition: border-color .3s ease;
        }

        .status-title {
            font-size: 10px;
            color: var(--muted2);
            margin-bottom: 8px;
            font-weight: 800;
            letter-spacing: .8px;
            text-transform: uppercase;
        }

        .status-text {
            font-size: 14px;
            color: var(--txt);
            font-weight: 700;
            min-height: 24px;
            line-height: 1.4;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: color 0.5s ease;
        }

        .status-foot {
            font-size: 11px;
            color: var(--muted2);
            text-align: center;
        }

        .status-box.error {
            border-color: rgba(255,43,43,.35);
        }

        .status-box.warning {
            border-color: rgba(245,165,36,.35);
        }

        .status-box.success {
            border-color: rgba(25,195,125,.35);
        }

        .status-box.error .status-text {
            color: var(--accent);
        }

        .status-box.warning .status-text {
            color: var(--warn);
        }

        .status-box.success .status-text {
            color: var(--ok);
        }

        .progress-container.complete .progress-ring-circle {
            stroke: var(--ok);
        }

        .progress-container.complete .percentage {
            color: var(--ok);
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
                box-shadow: 0 10px 24px rgba(255,43,43,.22);
            }
            50% {
                transform: scale(1.04);
                box-shadow: 0 12px 30px rgba(255,43,43,.38);
            }
            100% {
                transform: scale(1);
                box-shadow: 0 10px 24px rgba(255,43,43,.22);
            }
        }

        @media (max-width: 860px) {
            body {
                overflow: hidden;
            }

            .container {
                grid-template-columns: 1fr;
                gap: 14px;
                margin: 12px;
                height: min(460px, 88vh);
                padding: 18px;
            }

            .left-panel {
                align-items: center;
                text-align: center;
            }

            .brand {
                align-items: center;
            }

            .meta {
                align-items: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="left-panel">
            <div class="brand">
                <div class="app-icon">AI</div>
                <div class="app-name">JARVIS AI</div>
                <div class="app-tag">RECOVERY</div>
            </div>
            <div class="app-subtitle">
                Требуется интернет-соединение<br>для загрузки системы
            </div>
            <div class="meta">
                <div class="meta-line"><span class="meta-dot"></span> Система: проверка</div>
                <div class="meta-line"><span class="meta-dot"></span> Канал: защищен</div>
            </div>
        </div>
        
        <div class="right-panel">
            <div class="progress-container" id="progressContainer">
                <svg class="progress-ring" viewBox="0 0 140 140">
                    <circle class="progress-ring-bg" cx="70" cy="70" r="65"></circle>
                    <circle class="progress-ring-circle" id="progressCircle" 
                            cx="70" cy="70" r="65"></circle>
                </svg>
                <div class="percentage" id="percentage">0%</div>
            </div>
            
            <div class="status-container">
                <div class="status-box">
                    <div class="status-title">СТАТУС ЗАГРУЗКИ</div>
                    <div class="status-text" id="statusText">Проверка подключения...</div>
                </div>
                <div class="status-foot">Подготовка модулей и сетевых сервисов</div>
            </div>
        </div>
    </div>

    <script>
        const radius = 65;
        const circumference = 2 * Math.PI * radius;
        
        const progressCircle = document.getElementById('progressCircle');
        const progressContainer = document.getElementById('progressContainer');
        const statusBox = document.querySelector('.status-box');
        progressCircle.style.strokeDasharray = `${circumference} ${circumference}`;
        progressCircle.style.strokeDashoffset = circumference;
        
        function updateStatus(text, percent) {
            const percentage = document.getElementById('percentage');
            const statusText = document.getElementById('statusText');
            const appIcon = document.querySelector('.app-icon');
            const appName = document.querySelector('.app-name');
            
            // РћР±РЅРѕРІР»СЏРµРј РїСЂРѕС†РµРЅС‚
            percentage.textContent = percent + '%';
            
            // РћР±РЅРѕРІР»СЏРµРј РєСЂСѓРіРѕРІРѕР№ РїСЂРѕРіСЂРµСЃСЃ
            const offset = circumference - (percent / 100) * circumference;
            progressCircle.style.strokeDashoffset = offset;
            
            // РћР±РЅРѕРІР»СЏРµРј С‚РµРєСЃС‚ СЃС‚Р°С‚СѓСЃР°
            statusText.textContent = text;
            
            // РЎР±СЂР°СЃС‹РІР°РµРј РєР»Р°СЃСЃС‹ СЃС‚Р°С‚СѓСЃР°
            statusBox.className = 'status-box';
            
            // РћРїСЂРµРґРµР»СЏРµРј С‚РёРї СЃРѕРѕР±С‰РµРЅРёСЏ Рё СѓСЃС‚Р°РЅР°РІР»РёРІР°РµРј С†РІРµС‚
            if (text.includes('ОШИБКА') || text.includes('нет доступа') || text.includes('нет соединения') || text.includes('требуется интернет')) {
                statusBox.classList.add('error');
                progressCircle.style.stroke = '#ff2b2b';
                percentage.style.color = '#ff2b2b';
                appIcon.style.background = 'linear-gradient(135deg, #ff2b2b 0%, #b80000 100%)';
            } 
            else if (text.includes('мало') || text.includes('Предупреждение')) {
                statusBox.classList.add('warning');
                progressCircle.style.stroke = '#f5a524';
                percentage.style.color = '#f5a524';
            }
            else if (text.includes('OK') || percent >= 85) {
                statusBox.classList.add('success');
                
                if (percent >= 85) {
                    progressCircle.style.stroke = '#19c37d';
                    percentage.style.color = '#19c37d';
                    appIcon.style.background = 'linear-gradient(135deg, #19c37d 0%, #0f8a56 100%)';
                    appName.style.background = 'linear-gradient(90deg, #34d399, #19c37d)';
                    appName.style.webkitBackgroundClip = 'text';
                    appName.style.webkitTextFillColor = 'transparent';
                } else {
                    progressCircle.style.stroke = '#ff2b2b';
                    percentage.style.color = '#e8edf7';
                }
            }
            else {
                // РЎС‚Р°РЅРґР°СЂС‚РЅС‹Р№ Р°РєС†РµРЅС‚РЅС‹Р№
                progressCircle.style.stroke = '#ff2b2b';
                percentage.style.color = '#e8edf7';
                appIcon.style.background = 'linear-gradient(135deg, #ff2b2b 0%, #b80000 100%)';
                appName.style.color = '#e8edf7';
            }
            
            // Р”РѕР±Р°РІР»СЏРµРј РєР»Р°СЃСЃ complete РїСЂРё 100% Рё СѓСЃРїРµС…Рµ
            if (percent === 100 && !text.includes('ОШИБКА')) {
                progressContainer.classList.add('complete');
            } else {
                progressContainer.classList.remove('complete');
            }
        }
        
        // РРЅРёС†РёР°Р»РёР·Р°С†РёСЏ
        document.addEventListener('DOMContentLoaded', function() {
            updateStatus('Проверка подключения к интернету...', 0);
        });
    </script>
</body>
</html>"""

if __name__ == '__main__':
    if MAIN_MODE_ARG in sys.argv:
        sys.argv = [arg for arg in sys.argv if arg != MAIN_MODE_ARG]
        try:
            raise SystemExit(_run_main_inline())
        except Exception as e:
            _log(f"fatal in main inline: {e}")
            raise

    # Р Р°Р·РјРµСЂС‹ РѕРєРЅР°
    window_width = 900
    window_height = 500
    
    # РџРѕР»СѓС‡Р°РµРј РєРѕРѕСЂРґРёРЅР°С‚С‹ РґР»СЏ С†РµРЅС‚СЂРёСЂРѕРІР°РЅРёСЏ
    x, y = get_center_position(window_width, window_height)
    
    # РЎРѕР·РґР°РµРј Р“РћР РР—РћРќРўРђР›Р¬РќРћР• РѕРєРЅРѕ РїРѕ С†РµРЅС‚СЂСѓ
    window = webview.create_window(
        "JARVIS AI - Загрузка",
        html=html,
        width=window_width,
        height=window_height,
        x=x,  # РџРѕР·РёС†РёСЏ X (РµСЃР»Рё None - Р±СѓРґРµС‚ РїРѕ С†РµРЅС‚СЂСѓ)
        y=y,  # РџРѕР·РёС†РёСЏ Y (РµСЃР»Рё None - Р±СѓРґРµС‚ РїРѕ С†РµРЅС‚СЂСѓ)
        background_color="#07090d",
        frameless=False,
        resizable=False,
        easy_drag=False,
        on_top=True
    )
    
    # Р—Р°РїСѓСЃРєР°РµРј Р·Р°РіСЂСѓР·РєСѓ
    loading_thread = threading.Thread(target=simulate_loading, args=(window,))
    loading_thread.daemon = True
    loading_thread.start()
    
    # Р—Р°РїСѓСЃРєР°РµРј РїСЂРёР»РѕР¶РµРЅРёРµ
    webview.start()
