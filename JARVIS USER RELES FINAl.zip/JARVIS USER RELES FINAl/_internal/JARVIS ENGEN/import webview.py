﻿import webview
import os
import uuid
import hashlib
import platform
import subprocess
import shutil
import webbrowser
import requests
import json
import threading
import time
import tempfile
from pathlib import Path
import sys
from datetime import datetime, timezone, UTC
import builtins
import tkinter as tk
import config_manager
from command_router import CommandRouter, self_test as command_self_test
import actions_windows
import sound_player
from text_normalizer import normalize_text

SUPABASE_URL = "https://hikpmunrcmlqgjnzkmhd.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhpa3BtdW5yY21scWdqbnprbWhkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgxNTE4OTUsImV4cCI6MjA4MzcyNzg5NX0.FSDQLHcglva97FWOHcvXVFGn9lJC0nHGxbmnHpiDL8k"
TABLE_NAME = "users"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(
    os.getenv("LOCALAPPDATA") or tempfile.gettempdir(),
    "JARVIS_AI",
)
os.makedirs(DATA_DIR, exist_ok=True)
RUNTIME_LOG = os.path.join(DATA_DIR, "runtime.log")
STARTUP_CACHE_FILE = os.path.join(DATA_DIR, "jarvis_startup_cache.json")
STARTUP_CACHE_TTL_SEC = 180
TIME_GUARD_FILE = os.path.join(DATA_DIR, "jarvis_time_guard.json")
TIME_ROLLBACK_ALLOW_SEC = 300
QUIET = True

def print(*args, **kwargs):
    if not QUIET:
        builtins.print(*args, **kwargs)


def log_runtime(message):
    try:
        with open(RUNTIME_LOG, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().isoformat(sep=' ', timespec='seconds')}] [main] {message}\n")
    except Exception:
        pass

def normalize_user_name(value):
    if not isinstance(value, str) or not value:
        return "Гость"
    value = value.strip()
    if not value:
        return "Гость"
    allowed_ru = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя"
    allowed = set(allowed_ru + "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 -_.'")
    for ch in value:
        if ch not in allowed:
            return "Гость"
    return value

def read_text_file(path):
    with open(path, "rb") as f:
        data = f.read()

    def score_text(text):
        cyr = sum(1 for ch in text if "\u0400" <= ch <= "\u04FF")
        bad = sum(1 for ch in text if ch in "\u0420\u0421\u00d0\u00d1")
        return (cyr, -bad)

    best_text = None
    best_score = (-1, 0)

    for enc in ("utf-8", "utf-8-sig", "cp1251", "latin1"):
        try:
            text = data.decode(enc)
        except Exception:
            continue
        score = score_text(text)
        if score > best_score:
            best_text = text
            best_score = score

    return best_text if best_text is not None else data.decode("utf-8", errors="ignore")


def find_instructions_html():
    candidates = [
        "Инструкции JARVIS.html",
        "instructions.html",
    ]
    for name in candidates:
        path = os.path.join(BASE_DIR, name)
        if os.path.exists(path):
            return path
    return None


def ensure_runtime_instructions_file():
    src = find_instructions_html()
    if not src:
        return None
    try:
        dst = os.path.join(DATA_DIR, os.path.basename(src))
        shutil.copy2(src, dst)
        return dst
    except Exception:
        return None


def _parse_iso_datetime(value):
    if not value:
        return None
    try:
        text = str(value).strip()
        if not text:
            return None
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        return dt
    except Exception:
        return None


def _save_startup_cache(hwid, supabase_connected, subscription_info):
    try:
        payload = {
            "created_at": datetime.now(UTC).isoformat(),
            "hwid": hwid,
            "supabase_connected": bool(supabase_connected),
            "subscription_info": subscription_info or {},
        }
        with open(STARTUP_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False)
    except Exception:
        pass


def _load_startup_cache(hwid):
    try:
        if not os.path.exists(STARTUP_CACHE_FILE):
            return None

        with open(STARTUP_CACHE_FILE, "r", encoding="utf-8") as f:
            payload = json.load(f)

        if payload.get("hwid") != hwid:
            return None

        created_at = _parse_iso_datetime(payload.get("created_at"))
        if not created_at:
            return None

        age_sec = (datetime.now(UTC) - created_at).total_seconds()
        if age_sec < 0 or age_sec > STARTUP_CACHE_TTL_SEC:
            return None

        subscription_info = payload.get("subscription_info")
        if not isinstance(subscription_info, dict):
            return None

        return {
            "supabase_connected": bool(payload.get("supabase_connected", False)),
            "subscription_info": subscription_info,
        }
    except Exception:
        return None


def _load_time_guard(hwid):
    try:
        if not os.path.exists(TIME_GUARD_FILE):
            return None
        with open(TIME_GUARD_FILE, "r", encoding="utf-8") as f:
            payload = json.load(f)
        if payload.get("hwid") != hwid:
            return None
        return _parse_iso_datetime(payload.get("last_seen_utc"))
    except Exception:
        return None


def _save_time_guard(hwid, dt_utc):
    try:
        payload = {
            "hwid": hwid,
            "last_seen_utc": dt_utc.isoformat(),
            "updated_at": datetime.now(UTC).isoformat(),
        }
        with open(TIME_GUARD_FILE, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False)
    except Exception:
        pass


def _check_time_rollback(hwid):
    now_utc = datetime.now(UTC)
    last_seen_utc = _load_time_guard(hwid)
    if not last_seen_utc:
        return True, None
    rollback_threshold = now_utc.timestamp() + TIME_ROLLBACK_ALLOW_SEC
    if rollback_threshold < last_seen_utc.timestamp():
        return False, last_seen_utc
    return True, last_seen_utc


def _touch_time_guard(hwid):
    now_utc = datetime.now(UTC)
    last_seen_utc = _load_time_guard(hwid)
    if last_seen_utc and last_seen_utc.timestamp() > now_utc.timestamp():
        return
    _save_time_guard(hwid, now_utc)


def _get_filedialog():
    try:
        from tkinter import filedialog as tk_filedialog
        return tk_filedialog
    except Exception:
        return None


def _prepare_webview_runtime():
    try:
        candidates = []
        meipass = getattr(sys, "_MEIPASS", "")
        if meipass:
            candidates.append(os.path.join(meipass, "webview", "lib"))
        try:
            webview_dir = os.path.dirname(os.path.abspath(webview.__file__))
            candidates.append(os.path.join(webview_dir, "lib"))
        except Exception:
            pass
        candidates.append(os.path.join(BASE_DIR, "webview", "lib"))

        for lib_dir in candidates:
            if not lib_dir or not os.path.isdir(lib_dir):
                continue
            native_dir = os.path.join(lib_dir, "runtimes", "win-x64", "native")

            if lib_dir not in sys.path:
                sys.path.insert(0, lib_dir)
            if os.path.isdir(native_dir) and native_dir not in sys.path:
                sys.path.insert(0, native_dir)

            path_parts = os.environ.get("PATH", "").split(os.pathsep)
            for item in (lib_dir, native_dir):
                if item and os.path.isdir(item) and item not in path_parts:
                    path_parts.insert(0, item)
            os.environ["PATH"] = os.pathsep.join(path_parts)

            try:
                if hasattr(os, "add_dll_directory"):
                    os.add_dll_directory(lib_dir)
                    if os.path.isdir(native_dir):
                        os.add_dll_directory(native_dir)
            except Exception:
                pass

            # Explicitly preload WebView2 .NET assemblies for pythonnet backend.
            try:
                import clr  # type: ignore
                import System  # type: ignore
                from System.Reflection import Assembly  # type: ignore

                for dll_name in ("Microsoft.Web.WebView2.Core.dll", "Microsoft.Web.WebView2.WinForms.dll"):
                    dll_path = os.path.join(lib_dir, dll_name)
                    if not os.path.exists(dll_path):
                        continue
                    try:
                        Assembly.LoadFile(dll_path)
                    except Exception:
                        pass
                    try:
                        clr.AddReference(dll_path)
                    except Exception:
                        try:
                            clr.AddReferenceToFileAndPath(dll_path)
                        except Exception:
                            try:
                                clr.AddReference(os.path.splitext(dll_name)[0])
                            except Exception:
                                pass
            except Exception:
                pass
    except Exception:
        pass


class JarvisAPI:
    def __init__(self):
        config_manager.ensure_configs()
        self.router = CommandRouter()
        self._pending_hello_token = None
        self._pending_lock = threading.Lock()
        self._last_input = ""
        self._last_input_at = 0.0
        self._input_lock = threading.Lock()
        self._duplicate_window_sec = 1.2

    def _schedule_hello(self):
        token = time.monotonic()
        with self._pending_lock:
            self._pending_hello_token = token

        def _worker():
            time.sleep(0.7)
            with self._pending_lock:
                if self._pending_hello_token != token:
                    return
                self._pending_hello_token = None
            sound_player.play_hello()

        threading.Thread(target=_worker, daemon=True).start()

    def _cancel_pending_hello(self):
        with self._pending_lock:
            self._pending_hello_token = None

    def handle_speech(self, text):
        normalized = normalize_text(text)
        if not normalized:
            return {"status": "ignored", "message": "", "active": self.router.active}

        now = time.monotonic()
        with self._input_lock:
            is_duplicate = (
                normalized == self._last_input
                and (now - self._last_input_at) <= self._duplicate_window_sec
            )
            self._last_input = normalized
            self._last_input_at = now

        if is_duplicate:
            return {"status": "ignored", "message": "", "active": self.router.active}

        result = self.router.process(text)
        event = result.get("event")

        if event == "ignore":
            return {"status": "ignored", "message": "", "active": self.router.active}

        if event == "deactivated":
            self._cancel_pending_hello()
            sound_player.play_turn_off()
            return {
                "status": "deactivated",
                "message": "Режим команд отключен",
                "active": self.router.active,
            }

        if event == "activated_only":
            self._schedule_hello()
            return {
                "status": "activated",
                "message": "Режим команд активирован",
                "active": self.router.active,
            }

        if event == "error":
            sound_player.play_error()
            return {
                "status": "error",
                "message": "Команда не распознана",
                "active": self.router.active,
            }

        if event == "command":
            self._cancel_pending_hello()
            cmd = result.get("command", {})
            params = result.get("params", {})
            ok, message = self._execute_command(cmd, params)
            if ok:
                sound_player.play_success()
                return {
                    "status": "ok",
                    "message": message,
                    "command": cmd.get("id"),
                    "active": self.router.active,
                }
            sound_player.play_error()
            return {
                "status": "error",
                "message": message or "Команда не выполнена",
                "command": cmd.get("id"),
                "active": self.router.active,
            }

        sound_player.play_error()
        return {
            "status": "error",
            "message": "Неизвестное состояние",
            "active": self.router.active,
        }

    def _execute_command(self, cmd, params):
        action = cmd.get("action")

        if action == "open_url":
            url = cmd.get("url")
            if not url:
                return False, "URL не задан"
            ok, msg = actions_windows.open_url(url)
            if ok:
                return True, f"Открываю: {url}"
            return False, msg

        if action == "search_web":
            query = params.get("query", "")
            ok, msg = actions_windows.search_web(query)
            if ok:
                return True, f"Ищу: {query}"
            return False, msg

        if action == "run_program":
            path = cmd.get("path")
            return actions_windows.open_program(path)

        if action == "hotkeys":
            keys = cmd.get("keys", [])
            return actions_windows.press_hotkeys(keys)

        if action == "minimize_window":
            return actions_windows.minimize_window()

        if action == "close_window":
            return actions_windows.close_window()

        if action == "show_desktop":
            return actions_windows.show_desktop()

        return False, "Неизвестная команда"

    def run_self_test(self):
        return command_self_test()

    def _get_commands(self):
        return config_manager.load_commands()

    def _save_commands(self, commands):
        config_manager.save_commands(commands)
        self.router.reload()

    def list_custom_commands(self):
        commands = []
        for cmd in self._get_commands():
            if not cmd.get("user_created"):
                continue
            commands.append(
                {
                    "id": cmd.get("id"),
                    "name": cmd.get("name") or cmd.get("id") or "Команда",
                    "phrase": (cmd.get("phrases") or [""])[0],
                    "action": cmd.get("action"),
                    "path": cmd.get("path", ""),
                    "url": cmd.get("url", ""),
                    "keys": cmd.get("keys", []),
                }
            )
        return commands

    def _clean_phrase(self, value):
        if not isinstance(value, str):
            return ""
        return " ".join(value.strip().split())

    def _normalize_keys(self, keys):
        if isinstance(keys, str):
            keys = [k for k in keys.split("+") if k.strip()]
        if not isinstance(keys, list):
            return []
        normalized = []
        for item in keys:
            token = str(item).strip()
            if not token:
                continue
            normalized.append(token)
        return normalized

    def create_custom_command(self, payload):
        if not isinstance(payload, dict):
            return {"ok": False, "error": "Некорректные данные"}

        cmd_type = str(payload.get("type", "")).strip().lower()
        name = str(payload.get("name", "")).strip()
        phrase = self._clean_phrase(payload.get("phrase", ""))

        if not name:
            return {"ok": False, "error": "Введите название команды"}
        if not phrase:
            return {"ok": False, "error": "Введите фразу активации"}

        command = {
            "id": f"user_{int(time.time() * 1000)}",
            "name": name,
            "type": "phrase",
            "phrases": [phrase],
            "user_created": True,
        }

        if cmd_type == "program":
            path = str(payload.get("path", "")).strip()
            if not path:
                return {"ok": False, "error": "Выберите EXE файл"}
            command["action"] = "run_program"
            command["path"] = path
        elif cmd_type == "website":
            url = str(payload.get("url", "")).strip()
            if not url:
                return {"ok": False, "error": "Введите URL"}
            if not (url.startswith("http://") or url.startswith("https://")):
                url = "https://" + url
            command["action"] = "open_url"
            command["url"] = url
        elif cmd_type == "hotkeys":
            keys = self._normalize_keys(payload.get("keys", []))
            if not keys:
                return {"ok": False, "error": "Нажмите комбинацию клавиш"}
            command["action"] = "hotkeys"
            command["keys"] = keys
        else:
            return {"ok": False, "error": "Неизвестный тип команды"}

        commands = self._get_commands()
        commands.append(command)
        self._save_commands(commands)
        return {"ok": True, "command": command}

    def delete_custom_command(self, command_id):
        command_id = str(command_id or "").strip()
        if not command_id:
            return {"ok": False, "error": "ID команды не задан"}

        commands = self._get_commands()
        new_commands = []
        removed = False
        for cmd in commands:
            if cmd.get("id") == command_id and cmd.get("user_created"):
                removed = True
                continue
            new_commands.append(cmd)

        if not removed:
            return {"ok": False, "error": "Команда не найдена"}

        self._save_commands(new_commands)
        return {"ok": True}

    def run_custom_command(self, command_id):
        command_id = str(command_id or "").strip()
        if not command_id:
            return {"ok": False, "error": "ID команды не задан"}

        for cmd in self._get_commands():
            if cmd.get("id") != command_id:
                continue
            if not cmd.get("user_created"):
                return {"ok": False, "error": "Ручной запуск доступен только для пользовательских команд"}
            ok, message = self._execute_command(cmd, {})
            return {"ok": bool(ok), "message": message or ""}

        return {"ok": False, "error": "Команда не найдена"}

    def select_executable(self):
        try:
            tk_filedialog = _get_filedialog()
            if not tk_filedialog:
                return ""
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            path = tk_filedialog.askopenfilename(
                title="Выберите EXE файл",
                filetypes=[("Executable files", "*.exe"), ("All files", "*.*")],
            )
            root.destroy()
            return path or ""
        except Exception:
            return ""

    def open_instructions_window(self):
        path = find_instructions_html()
        if not path:
            return {"ok": False, "error": "Файл инструкций не найден"}

        try:
            webview.create_window(
                "JARVIS AI - Инструкции",
                path,
                width=1160,
                height=780,
                min_size=(860, 620),
                resizable=True,
                background_color="#07090d",
            )
            return {"ok": True, "mode": "app_window"}
        except Exception:
            try:
                webbrowser.open(Path(path).resolve().as_uri())
                return {"ok": True, "mode": "browser"}
            except Exception as e:
                return {"ok": False, "error": f"Не удалось открыть инструкции: {e}"}

    def _clean_phrases(self, values, default_phrase):
        if not isinstance(values, list):
            return [default_phrase]
        cleaned = []
        for item in values:
            phrase = self._clean_phrase(item)
            if phrase:
                cleaned.append(phrase)
            if len(cleaned) >= 5:
                break
        return cleaned or [default_phrase]

    def _normalize_sound_entries(self, values):
        if not isinstance(values, list):
            return []
        out = []
        for item in values:
            path = str(item).strip()
            if path:
                out.append(path)
        return out

    def _list_audio_devices(self):
        microphones = []
        outputs = []

        try:
            import sounddevice as sd  # type: ignore

            for dev in sd.query_devices():
                name = str(dev.get("name", "")).strip()
                if not name:
                    continue
                if int(dev.get("max_input_channels", 0) or 0) > 0:
                    microphones.append(name)
                if int(dev.get("max_output_channels", 0) or 0) > 0:
                    outputs.append(name)
        except Exception:
            pass

        def _uniq(items):
            seen = set()
            out = []
            for item in items:
                key = item.casefold()
                if key in seen:
                    continue
                seen.add(key)
                out.append(item)
            return out

        microphones = _uniq(microphones)
        outputs = _uniq(outputs)
        if not microphones:
            microphones = ["Default Microphone"]
        if not outputs:
            outputs = ["Default Output"]

        return {"microphones": microphones, "outputs": outputs}

    def get_settings(self):
        config_manager.ensure_configs()
        settings = config_manager.load_settings()
        activation_phrases = config_manager.load_activation_phrases()
        deactivation_phrases = config_manager.load_deactivation_phrases()
        devices = self._list_audio_devices()

        sounds = settings.get("sounds", {}) if isinstance(settings, dict) else {}
        default_sounds = config_manager.DEFAULT_SETTINGS.get("sounds", {})

        return {
            "ok": True,
            "settings": {
                "wakePhrases": activation_phrases or ["Джарвис"],
                "deactivationPhrases": deactivation_phrases or ["Спасибо Джарвис"],
                "voice": settings.get("voice", "Default"),
                "showConsole": bool(settings.get("show_console", True)),
                "playErrorSound": bool(settings.get("play_error_sound", True)),
                "microphone": settings.get("microphone", "Default Microphone"),
                "outputDevice": settings.get("output_device", "Default Output"),
                "autoUpdateSoon": bool(settings.get("auto_update_soon", False)),
                "analyticsEnabled": bool(settings.get("analytics_enabled", False)),
                "sounds": {
                    "activation": self._normalize_sound_entries(sounds.get("activation", default_sounds.get("activation", []))),
                    "deactivation": self._normalize_sound_entries(sounds.get("deactivation", default_sounds.get("deactivation", []))),
                    "error": self._normalize_sound_entries(sounds.get("error", default_sounds.get("error", []))),
                    "success": self._normalize_sound_entries(sounds.get("success", default_sounds.get("success", []))),
                },
                "devices": devices,
            },
        }

    def save_settings(self, payload):
        if not isinstance(payload, dict):
            return {"ok": False, "error": "Некорректные данные настроек"}

        wake_phrases = self._clean_phrases(payload.get("wakePhrases", []), "Джарвис")
        deactivation_phrases = self._clean_phrases(
            payload.get("deactivationPhrases", []),
            "Спасибо Джарвис",
        )

        sounds_in = payload.get("sounds", {})
        if not isinstance(sounds_in, dict):
            sounds_in = {}

        settings = {
            "voice": str(payload.get("voice", "Default")).strip() or "Default",
            "show_console": bool(payload.get("showConsole", True)),
            "play_error_sound": bool(payload.get("playErrorSound", True)),
            "microphone": str(payload.get("microphone", "Default Microphone")).strip() or "Default Microphone",
            "output_device": str(payload.get("outputDevice", "Default Output")).strip() or "Default Output",
            "auto_update_soon": bool(payload.get("autoUpdateSoon", False)),
            "analytics_enabled": bool(payload.get("analyticsEnabled", False)),
            "sounds": {
                "activation": self._normalize_sound_entries(sounds_in.get("activation", [])),
                "deactivation": self._normalize_sound_entries(sounds_in.get("deactivation", [])),
                "error": self._normalize_sound_entries(sounds_in.get("error", [])),
                "success": self._normalize_sound_entries(sounds_in.get("success", [])),
            },
        }

        config_manager.save_activation_phrases(wake_phrases)
        config_manager.save_deactivation_phrases(deactivation_phrases)
        config_manager.save_settings(settings)
        self.router.reload()
        sound_player.reload_settings()
        return {"ok": True}

    def list_audio_devices(self):
        return {"ok": True, **self._list_audio_devices()}

    def select_sound_files(self):
        try:
            tk_filedialog = _get_filedialog()
            if not tk_filedialog:
                return []
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            paths = tk_filedialog.askopenfilenames(
                title="Выберите звуковые файлы",
                filetypes=[
                    ("Audio files", "*.wav *.mp3 *.ogg *.m4a *.aac *.flac"),
                    ("All files", "*.*"),
                ],
            )
            root.destroy()
            return list(paths or [])
        except Exception:
            return []

    def preview_sound(self, path):
        value = str(path or "").strip()
        if not value:
            return {"ok": False, "error": "Путь к звуку не задан"}
        ok = sound_player.play_sound(value)
        if ok:
            return {"ok": True}
        return {"ok": False, "error": "Не удалось воспроизвести файл"}

def test_supabase_connection():
    print("РўРµСЃС‚РёСЂСѓСЋ РїРѕРґРєР»СЋС‡РµРЅРёРµ Рє Supabase...")
    if not SUPABASE_URL or not SUPABASE_KEY:
        print("Supabase credentials not configured (JARVIS_SUPABASE_URL / JARVIS_SUPABASE_KEY)")
        return False
    
    test_url = f"{SUPABASE_URL}/rest/v1/"
    
    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.get(test_url, headers=headers, timeout=5)
        print(f"РљРѕРґ РѕС‚РІРµС‚Р°: {response.status_code}")
        
        if response.status_code == 200:
            print("РџРѕРґРєР»СЋС‡РµРЅРёРµ СѓСЃРїРµС€РЅРѕ!")
            return True
        elif response.status_code == 401:
            print("РћС€РёР±РєР° 401: РќРµРІРµСЂРЅС‹Р№ API РєР»СЋС‡")
            print("РџСЂРѕРІРµСЂСЊС‚Рµ РєР»СЋС‡ РІ Supabase Dashboard")
            return False
        else:
            print(f"РќРµРѕР¶РёРґР°РЅРЅС‹Р№ РєРѕРґ: {response.status_code}")
            return False
    except Exception as e:
        print(f"РћС€РёР±РєР° РїРѕРґРєР»СЋС‡РµРЅРёСЏ: {e}")
        return False

def get_hwid():
    try:
        def run_cmd(cmd):
            try:
                return subprocess.check_output(
                    cmd,
                    shell=True,
                    text=True,
                    errors="ignore",
                    timeout=5,
                    stderr=subprocess.DEVNULL,
                )
            except Exception:
                return ""

        def parse_value(output):
            if not output:
                return ""
            lines = [line.strip() for line in output.splitlines() if line.strip()]
            if not lines:
                return ""
            if len(lines) == 1 and "=" in lines[0]:
                return lines[0].split("=", 1)[1].strip()
            if len(lines) >= 2:
                header = lines[0].replace(" ", "").lower()
                if header in {"serialnumber", "processorid", "uuid"}:
                    lines = lines[1:]
            return lines[0].strip() if lines else ""

        def clean_value(value):
            if not value:
                return ""
            value = value.strip()
            if not value:
                return ""
            lower = value.lower()
            invalid_tokens = [
                "to be filled",
                "default string",
                "unknown",
                "none",
                "n/a",
                "invalid",
                "o.e.m",
                "oem",
                "not applicable",
            ]
            if any(token in lower for token in invalid_tokens):
                return ""
            return value

        def first_value(commands):
            for cmd in commands:
                if not cmd:
                    continue
                value = clean_value(parse_value(run_cmd(cmd)))
                if value:
                    return value
            return ""

        parts = []
        if os.name == "nt":
            has_wmic = shutil.which("wmic") is not None
            bios = first_value([
                "wmic bios get serialnumber /value" if has_wmic else "",
                "powershell -NoProfile -Command \"(Get-CimInstance Win32_BIOS).SerialNumber\"",
            ])
            baseboard = first_value([
                "wmic baseboard get serialnumber /value" if has_wmic else "",
                "powershell -NoProfile -Command \"(Get-CimInstance Win32_BaseBoard).SerialNumber\"",
            ])
            cpu = first_value([
                "wmic cpu get processorid /value" if has_wmic else "",
                "powershell -NoProfile -Command \"(Get-CimInstance Win32_Processor | Select-Object -First 1).ProcessorId\"",
            ])
            disk = first_value([
                "wmic diskdrive get serialnumber /value" if has_wmic else "",
                "powershell -NoProfile -Command \"(Get-CimInstance Win32_DiskDrive | Select-Object -First 1).SerialNumber\"",
            ])
            sys_uuid = first_value([
                "wmic csproduct get uuid /value" if has_wmic else "",
                "powershell -NoProfile -Command \"(Get-CimInstance Win32_ComputerSystemProduct).UUID\"",
            ])

            if bios:
                parts.append(f"bios:{bios}")
            if baseboard:
                parts.append(f"baseboard:{baseboard}")
            if cpu:
                parts.append(f"cpu:{cpu}")
            if disk:
                parts.append(f"disk:{disk}")
            if sys_uuid:
                parts.append(f"uuid:{sys_uuid}")

        if not parts:
            system_info = f"{platform.node()}{platform.processor()}{platform.machine()}"
            parts.append(system_info)

        hwid = hashlib.sha256("|".join(parts).encode()).hexdigest()
        return hwid
    except Exception as e:
        print(f"РћС€РёР±РєР° РїСЂРё РїРѕР»СѓС‡РµРЅРёРё HWID: {e}")
        return hashlib.sha256(str(uuid.uuid4()).encode()).hexdigest()

def check_subscription_local(hwid):
    print("РСЃРїРѕР»СЊР·СѓСЋ Р»РѕРєР°Р»СЊРЅСѓСЋ РїСЂРѕРІРµСЂРєСѓ...")
    
    test_data = {
        "00f00957dcaf7f2f45f055f94daef14fca63be9fba2c3e89277d18cea649ea38": {
            "first_name": "РђР»РµРєСЃР°РЅРґСЂ",
            "subscription_key": "VOICETECH2:ZVDT-S08Y-DGZI",
            "key_expiry": "2026-02-15T22:09:32.032",
            "device_count": 1,
            "last_activation": "2026-01-25T21:58:49.635958+00:00"
        },
        "test_hwid_123": {
            "first_name": "РЎР•Р Р“Р•Р™",
            "subscription_key": "VOICETECH1:TEST-KEY-123",
            "key_expiry": "2026-12-31T23:59:59.999",
            "device_count": 1,
            "last_activation": datetime.now(timezone.utc).isoformat()
        }
    }
    
    if hwid in test_data:
        user_data = test_data[hwid]
        print(f"РќР°Р№РґРµРЅ РїРѕР»СЊР·РѕРІР°С‚РµР»СЊ РІ Р»РѕРєР°Р»СЊРЅРѕР№ Р±Р°Р·Рµ: {user_data['first_name']}")
        
        subscription_active = False
        message = "РџРѕРґРїРёСЃРєР° РЅРµ Р°РєС‚РёРІРЅР°"
        
        if user_data.get('subscription_key'):
            if user_data.get('key_expiry'):
                try:
                    expiry_str = user_data['key_expiry']
                    if 'Z' in expiry_str:
                        expiry_date = datetime.fromisoformat(expiry_str.replace('Z', '+00:00'))
                    elif '+' in expiry_str:
                        expiry_date = datetime.fromisoformat(expiry_str)
                    else:
                        expiry_date = datetime.fromisoformat(expiry_str).replace(tzinfo=timezone.utc)
                    
                    current_date = datetime.now(timezone.utc)
                    
                    if expiry_date > current_date:
                        subscription_active = True
                        expiry_display = expiry_date.strftime("%d.%m.%Y %H:%M")
                        message = f"РџРѕРґРїРёСЃРєР° Р°РєС‚РёРІРЅР° РґРѕ {expiry_display}"
                    else:
                        expiry_display = expiry_date.strftime("%d.%m.%Y %H:%M")
                        message = f"РЎСЂРѕРє РїРѕРґРїРёСЃРєРё РёСЃС‚РµРє {expiry_display}"
                        
                    print(f"Р”Р°С‚Р° РёСЃС‚РµС‡РµРЅРёСЏ: {expiry_date}")
                    print(f"РўРµРєСѓС‰Р°СЏ РґР°С‚Р°: {current_date}")
                    print(f"РђРєС‚РёРІРЅР°: {expiry_date > current_date}")
                        
                except Exception as e:
                    print(f"РћС€РёР±РєР° РїСЂРё РїСЂРѕРІРµСЂРєРµ СЃСЂРѕРєР°: {e}")
                    print(f"РЎС‚СЂРѕРєР° РґР°С‚С‹: {user_data['key_expiry']}")
                    message = "РћС€РёР±РєР° РїСЂРѕРІРµСЂРєРё СЃСЂРѕРєР° РїРѕРґРїРёСЃРєРё"
            else:
                subscription_active = True
                message = "РџРѕРґРїРёСЃРєР° Р°РєС‚РёРІРЅР° (Р±РµСЃСЃСЂРѕС‡РЅР°СЏ)"
        else:
            message = "РљР»СЋС‡ РїРѕРґРїРёСЃРєРё РѕС‚СЃСѓС‚СЃС‚РІСѓРµС‚"
        
        print(f"РЎС‚Р°С‚СѓСЃ: {message}")
        
        return {
            "found": True,
            "first_name": user_data['first_name'],
            "subscription_active": subscription_active,
            "subscription_key": user_data.get('subscription_key'),
            "key_expiry": user_data.get('key_expiry'),
            "device_count": user_data.get('device_count', 0),
            "last_activation": user_data.get('last_activation'),
            "message": message,
            "source": "local"
        }
    else:
        print("HWID РЅРµ РЅР°Р№РґРµРЅ РІ Р»РѕРєР°Р»СЊРЅРѕР№ Р±Р°Р·Рµ")
        return {
            "found": False,
            "first_name": "Р“РѕСЃС‚СЊ",
            "subscription_active": False,
            "message": "Доступ заблокирован или закончилась подписка. Перезагрузите программу.",
            "source": "local"
        }

def check_subscription_supabase(hwid):
    try:
        url = f"{SUPABASE_URL}/rest/v1/{TABLE_NAME}?hwid=eq.{hwid}&select=first_name,subscription_key,key_expiry,device_count,last_activation"
        
        headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}",
            "Content-Type": "application/json"
        }
        
        print(f"РћС‚РїСЂР°РІРєР° Р·Р°РїСЂРѕСЃР° РІ Supabase...")
        print(f"HWID: {hwid[:16]}...")
        
        response = requests.get(url, headers=headers, timeout=10)
        response.encoding = "utf-8"
        
        if response.status_code == 200:
            data = response.json()
            
            if data and len(data) > 0:
                user_data = data[0]
                first_name = user_data.get('first_name', 'Пользователь')
                subscription_key = user_data.get('subscription_key')
                key_expiry = user_data.get('key_expiry')
                device_count = int(user_data.get('device_count', 0))
                last_activation = user_data.get('last_activation')
                
                print(f"РќР°Р№РґРµРЅ РїРѕР»СЊР·РѕРІР°С‚РµР»СЊ: {first_name}")
                
                subscription_active = False
                message = "РџРѕРґРїРёСЃРєР° РЅРµ Р°РєС‚РёРІРЅР°"
                
                if subscription_key:
                    if key_expiry:
                        try:
                            expiry_str = str(key_expiry)
                            if 'Z' in expiry_str:
                                expiry_date = datetime.fromisoformat(expiry_str.replace('Z', '+00:00'))
                            elif '+' in expiry_str:
                                expiry_date = datetime.fromisoformat(expiry_str)
                            else:
                                expiry_date = datetime.fromisoformat(expiry_str).replace(tzinfo=timezone.utc)
                            
                            current_date = datetime.now(timezone.utc)
                            
                            if expiry_date > current_date:
                                subscription_active = True
                                expiry_display = expiry_date.strftime("%d.%m.%Y %H:%M")
                                message = f"РџРѕРґРїРёСЃРєР° Р°РєС‚РёРІРЅР° РґРѕ {expiry_display}"
                            else:
                                expiry_display = expiry_date.strftime("%d.%m.%Y %H:%M")
                                message = f"РЎСЂРѕРє РїРѕРґРїРёСЃРєРё РёСЃС‚РµРє {expiry_display}"
                                
                        except Exception as e:
                            print(f"РћС€РёР±РєР° РїСЂРё РїСЂРѕРІРµСЂРєРµ СЃСЂРѕРєР°: {e}")
                            print(f"РЎС‚СЂРѕРєР° РґР°С‚С‹: {key_expiry}")
                            message = "РћС€РёР±РєР° РїСЂРѕРІРµСЂРєРё СЃСЂРѕРєР° РїРѕРґРїРёСЃРєРё"
                    else:
                        subscription_active = True
                        message = "РџРѕРґРїРёСЃРєР° Р°РєС‚РёРІРЅР° (Р±РµСЃСЃСЂРѕС‡РЅР°СЏ)"
                else:
                    message = "РљР»СЋС‡ РїРѕРґРїРёСЃРєРё РѕС‚СЃСѓС‚СЃС‚РІСѓРµС‚"
                
                print(f"РЎС‚Р°С‚СѓСЃ: {message}")
                
                return {
                    "found": True,
                    "first_name": first_name,
                    "subscription_active": subscription_active,
                    "subscription_key": subscription_key,
                    "key_expiry": key_expiry,
                    "device_count": device_count,
                    "last_activation": last_activation,
                    "message": message,
                    "source": "supabase",
                    "db_access": True
                }
            else:
                print("HWID РЅРµ РЅР°Р№РґРµРЅ РІ Р±Р°Р·Рµ РґР°РЅРЅС‹С…")
                return {
                    "found": False,
                    "first_name": "Р“РѕСЃС‚СЊ",
                    "subscription_active": False,
                    "message": "Доступ заблокирован или закончилась подписка. Перезагрузите программу.",
                    "source": "supabase",
                    "db_access": True
                }
        else:
            print(f"РћС€РёР±РєР° Р·Р°РїСЂРѕСЃР°: {response.status_code}")
            return {
                "found": False,
                "first_name": "Р“РѕСЃС‚СЊ",
                "subscription_active": False,
                "message": f"РћС€РёР±РєР° РїРѕРґРєР»СЋС‡РµРЅРёСЏ: {response.status_code}",
                "source": "supabase",
                "db_access": False
            }
            
    except requests.exceptions.ConnectionError:
        print("РќРµС‚ РїРѕРґРєР»СЋС‡РµРЅРёСЏ Рє РёРЅС‚РµСЂРЅРµС‚Сѓ")
        return {
            "found": False,
            "first_name": "Р“РѕСЃС‚СЊ",
            "subscription_active": False,
            "message": "РќРµС‚ РїРѕРґРєР»СЋС‡РµРЅРёСЏ Рє РёРЅС‚РµСЂРЅРµС‚Сѓ",
            "source": "supabase",
            "db_access": False
        }
    except Exception as e:
        print(f"РћС€РёР±РєР° РїСЂРё РїСЂРѕРІРµСЂРєРµ РїРѕРґРїРёСЃРєРё: {e}")
        return {
            "found": False,
            "first_name": "Р“РѕСЃС‚СЊ",
            "subscription_active": False,
            "message": f"РћС€РёР±РєР° СЃРёСЃС‚РµРјС‹: {str(e)}",
            "source": "supabase",
            "db_access": False
        }


def preload_startup_data():
    hwid = get_hwid()
    time_ok, _ = _check_time_rollback(hwid)
    if not time_ok:
        return False
    _touch_time_guard(hwid)
    supabase_connected = test_supabase_connection()
    if supabase_connected:
        subscription_info = check_subscription_supabase(hwid)
    else:
        subscription_info = check_subscription_local(hwid)
    _save_startup_cache(hwid, supabase_connected, subscription_info)
    return True

def inject_user_data(html_content, user_name, subscription_status, subscription_info):
    try:
        key_expiry_display = subscription_info.get('key_expiry', '')
        if key_expiry_display:
            try:
                expiry_str = str(key_expiry_display)
                if 'Z' in expiry_str:
                    expiry_date = datetime.fromisoformat(expiry_str.replace('Z', '+00:00'))
                elif '+' in expiry_str:
                    expiry_date = datetime.fromisoformat(expiry_str)
                else:
                    expiry_date = datetime.fromisoformat(expiry_str).replace(tzinfo=timezone.utc)
                
                key_expiry_display = expiry_date.strftime("%d.%m.%Y %H:%M")
            except:
                key_expiry_display = "РќРµС‚ РґР°РЅРЅС‹С…"

        try:
            device_count = int(subscription_info.get("device_count", 0) or 0)
        except Exception:
            device_count = 0

        user_data = {
            "name": str(user_name or ""),
            "found": bool(subscription_info.get("found", False)),
            "subscriptionActive": bool(subscription_status),
            "blocked": bool((not subscription_info.get("found", False)) or (not subscription_status)),
            "subscriptionKey": str(subscription_info.get("subscription_key", "") or ""),
            "keyExpiry": str(key_expiry_display or ""),
            "deviceCount": device_count,
            "lastActivation": str(subscription_info.get("last_activation", "") or ""),
            "message": str(subscription_info.get("message", "") or ""),
            "source": str(subscription_info.get("source", "unknown") or "unknown"),
        }
        user_data_json = json.dumps(user_data, ensure_ascii=False)

        js_code = f"""
        <script>
        window.userData = {user_data_json};
        
        (function() {{
            function updateUserName() {{
                const userNameElement = document.getElementById('userName');
                if (userNameElement) {{
                    const safeName = String((window.userData && window.userData.name) || '');
                    userNameElement.textContent = safeName.toUpperCase();
                }}
            }}
            
            updateUserName();
            if (window.userData.blocked) {{
                const msg = window.userData.message || 'Доступ заблокирован или закончилась подписка. Перезагрузите программу.';
                const titleEl = document.getElementById('appErrorTitle');
                const textEl = document.getElementById('appErrorText');
                if (titleEl) titleEl.textContent = 'Доступ заблокирован';
                if (textEl) textEl.textContent = msg;
                document.body.classList.remove('app-ready');
                document.body.classList.add('app-blocked');
            }}
            
            if (document.readyState === 'loading') {{
                document.addEventListener('DOMContentLoaded', updateUserName);
            }}
        }})();
        </script>
        """
        
        if '</body>' in html_content:
            return html_content.replace('</body>', f'{js_code}</body>')
        else:
            return html_content + js_code
            
    except Exception as e:
        print(f"РћС€РёР±РєР° РїСЂРё РІРЅРµРґСЂРµРЅРёРё РґР°РЅРЅС‹С…: {e}")
        return html_content

def main():
    log_runtime("main start")
    _prepare_webview_runtime()
    print("=" * 60)
    print("JARVIS AI - РЎРРЎРўР•РњРђ РЈРџР РђР’Р›Р•РќРРЇ Р›РР¦Р•РќР—РРЇРњР")
    print("=" * 60)
    
    hwid = get_hwid()
    print(f"HWID СЃРёСЃС‚РµРјС‹: {hwid[:16]}...")
    print("-" * 60)
    preblocked_info = None
    time_ok, last_seen_utc = _check_time_rollback(hwid)
    if not time_ok:
        rollback_at = last_seen_utc.astimezone(UTC).strftime("%d.%m.%Y %H:%M:%S UTC")
        print("Обнаружен откат системного времени.")
        print(f"Последнее корректное время запуска: {rollback_at}")
        preblocked_info = {
            "found": False,
            "first_name": "Гость",
            "subscription_active": False,
            "message": "Обнаружен откат системного времени. Верните правильные дату/время и перезапустите программу.",
            "source": "local",
            "db_access": True,
        }
    else:
        _touch_time_guard(hwid)

    if preblocked_info is not None:
        supabase_connected = False
        subscription_info = preblocked_info
    else:
        cached = _load_startup_cache(hwid)
        if cached:
            supabase_connected = cached.get("supabase_connected", False)
            subscription_info = cached.get("subscription_info", {})
            print("РСЃРїРѕР»СЊР·СѓСЋ РїСЂРµРґР·Р°РіСЂСѓР¶РµРЅРЅС‹Рµ РґР°РЅРЅС‹Рµ Р·Р°РїСѓСЃРєР°...")
        else:
            supabase_connected = test_supabase_connection()
            if supabase_connected:
                print("РџСЂРѕРІРµСЂСЏСЋ РїРѕРґРїРёСЃРєСѓ РІ Supabase...")
                subscription_info = check_subscription_supabase(hwid)
            else:
                print("РСЃРїРѕР»СЊР·СѓСЋ Р»РѕРєР°Р»СЊРЅСѓСЋ РїСЂРѕРІРµСЂРєСѓ...")
                subscription_info = check_subscription_local(hwid)
            _save_startup_cache(hwid, supabase_connected, subscription_info)

    if not subscription_info.get("db_access", True):
        print("Р СњР ВµРЎвЂљ Р Т‘Р С•РЎРѓРЎвЂљРЎС“Р С—Р В° Р С” Р В±Р В°Р В·Р Вµ Р Т‘Р В°Р Р…Р Р…РЎвЂ№РЎвЂ¦. Р вЂ”Р В°Р С—РЎС“РЎРѓР С” Р С•РЎвЂљР СР ВµР Р…Р ВµР Р….")
        subscription_info = {
            "found": False,
            "first_name": "Гость",
            "subscription_active": False,
            "message": subscription_info.get("message") or "Нет доступа к базе данных. Запущен ограниченный режим.",
            "source": subscription_info.get("source", "supabase"),
            "db_access": False,
        }

    if "found" not in subscription_info:
        subscription_info["found"] = False
    if "subscription_active" not in subscription_info:
        subscription_info["subscription_active"] = False
    if "first_name" not in subscription_info:
        subscription_info["first_name"] = "Гость"
    if "message" not in subscription_info:
        subscription_info["message"] = ""
    if "source" not in subscription_info:
        subscription_info["source"] = "unknown"
    
    if not subscription_info.get("found"):
        user_name = "Гость"
    else:
        user_name = normalize_user_name(subscription_info["first_name"])
    subscription_info["first_name"] = user_name
    subscription_active = subscription_info["subscription_active"]
    
    if subscription_info["found"]:
        if subscription_active:
            print(f"Р›РёС†РµРЅР·РёСЏ Р°РєС‚РёРІРЅР°. Р”РѕР±СЂРѕ РїРѕР¶Р°Р»РѕРІР°С‚СЊ, {user_name}!")
        else:
            print(f"{subscription_info.get('message', 'Р›РёС†РµРЅР·РёСЏ РЅРµ Р°РєС‚РёРІРЅР°')}")
    else:
        print(f"{subscription_info.get('message', 'Р›РёС†РµРЅР·РёСЏ РЅРµ РѕР±РЅР°СЂСѓР¶РµРЅР°')}")
        print(f"РСЃРїРѕР»СЊР·СѓРµС‚СЃСЏ РіРѕСЃС‚РµРІРѕР№ СЂРµР¶РёРј")
    
    print(f"РСЃС‚РѕС‡РЅРёРє РґР°РЅРЅС‹С…: {subscription_info.get('source', 'unknown')}")
    print("-" * 60)
    
    html_files = [
        "\u041c\u043e\u0437\u0433\u0438 \u0431\u0435\u0437 \u0441\u043f\u0438\u043a.html",
        "\u0414\u0438\u0437\u0430\u0439\u043d + \u043c\u043e\u0437\u0433\u0438.html",
        "jarvis.html",
        "index.html",
    ]
    html_path = None
    
    for file_name in html_files:
        file_path = os.path.join(BASE_DIR, file_name)
        if os.path.exists(file_path):
            html_path = file_path
            print(f"РќР°Р№РґРµРЅ С„Р°Р№Р»: {file_name}")
            break
    
    if not html_path:
        try:
            candidates = [
                f for f in os.listdir(BASE_DIR)
                if f.lower().endswith(".html") and f.lower() != "jarvis_temp.html"
            ]
        except Exception:
            candidates = []

        if candidates:
            preferred = None
            for f in candidates:
                if "мозги" in f.casefold():
                    preferred = f
                    break
            chosen = preferred or candidates[0]
            html_path = os.path.join(BASE_DIR, chosen)
            print(f"HTML файл выбран: {chosen}")
        else:
            print("HTML файл не найден!")
            return
    
    try:
        temp_file = os.path.join(DATA_DIR, "jarvis_temp.html")
        ensure_runtime_instructions_file()
        log_runtime(f"html source path={html_path}")
        html_content = read_text_file(html_path)
        
        html_content = inject_user_data(html_content, user_name, subscription_active, subscription_info)
        
        with open(temp_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print("РРЅС‚РµСЂС„РµР№СЃ JARVIS РїРѕРґРіРѕС‚РѕРІР»РµРЅ")
        print("=" * 60)
        
        window_title = "JARVIS AI"
        
        window = webview.create_window(
            window_title,
            temp_file,
            width=1200,
            height=800,
            min_size=(800, 600),
            resizable=True,
            background_color="#07090d",
            js_api=JarvisAPI()
        )
        log_runtime("webview window created")
        
        print("Р—Р°РїСѓСЃРє JARVIS...")
        print("=" * 60)
        
        webview.start(debug=False, http_server=True, private_mode=False)
        log_runtime("webview start returned")
        
        print("JARVIS Р·Р°РІРµСЂС€РёР» СЂР°Р±РѕС‚Сѓ")
        
    except Exception as e:
        log_runtime(f"fatal main exception: {repr(e)}")
        print(f"РћС€РёР±РєР° РїСЂРё Р·Р°РїСѓСЃРєРµ: {e}")
    finally:
        if 'temp_file' in locals() and os.path.exists(temp_file):
            try:
                os.remove(temp_file)
                print("Р’СЂРµРјРµРЅРЅС‹Р№ С„Р°Р№Р» СѓРґР°Р»РµРЅ")
            except:
                pass

if __name__ == "__main__":
    if "--preload-startup" in sys.argv:
        ok = preload_startup_data()
        raise SystemExit(0 if ok else 1)
    main()
